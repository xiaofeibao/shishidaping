import Vue from 'vue'
import VueRouter from 'vue-router'
import Morning from '../views/Morning.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Morning',
    component: Morning
  },
  {
    path: '/noon',
    name: 'Noon',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/Noon.vue')
  },
  {
    path: '/afternoon',
    name: 'Afternoon',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/Afternoon.vue')
  },
  {
    path: '/end',
    name: 'End',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/End.vue')
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
