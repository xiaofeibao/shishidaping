<template>
  <div id="app">
    <!--<div id="nav">
      <router-link to="/">Morning</router-link>|
      <router-link to="/noon">Noon</router-link>|
      <router-link to="/afternoon">Afternoon</router-link>|
      <router-link to="/end">End</router-link>
    </div>-->

    <transition name="fold-left">
      <router-view />
    </transition>
  </div>
</template>

<script lang="ts">
import Vue from "vue";
import { createNamespacedHelpers } from "vuex";
const { mapState, mapActions } = createNamespacedHelpers("currentTime");
export default {
  name: "App",
  created: function() {},
  computed: {
    ...mapState({
      data: state => state.oriTime
    })
  },
  watch: {
    data(e) {
      let time = new Date(e);
      // let onLineDate = '2020/05/06';
			let str = time.getFullYear()+ '/'+ (time.getMonth()+1)+'/'+time.getDate();
      // if(time < new Date(str+' 08:30:00')){
      //   this.$router.push('morning');
      // }
      if((time > new Date(str+' 08:30:00')) && (time < new Date(str+' 09:00:00'))){   
        this.$router.push('noon').catch(err => {err});
      }
      else if((time > new Date(str+' 09:00:00')) && (time < new Date(str+' 23:59:59'))){   
        this.$router.push('afternoon').catch(err => {err});
      }
    }
  }
};
</script>

<style lang="less">
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  border: none;
}
:root {
  font-size: 0.833vw;
}
.clear {
  zoom: 1;
}
.clear:after {
  content: "";
  display: block;
  height: 0;
  clear: both;
  visibility: visible;
}
.textOverflow {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.fl {
  float: left;
}
.logo {
  background: url("./assets/logo.png") no-repeat center;
  background-size: 100% 100%;
  width: 14.3%;
  height: 9.7%;
  margin-left: 4.4%;
  margin-top: 1.1%;
  position: absolute;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  position: absolute;
  left: 0px;
  right: 0px;
  top: 0px;
  bottom: 0px;
}

#nav {
  padding: 1.875rem;
  z-index: 1000;
  position: absolute;
  left: 30%;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}

.fold-left-enter-active {
  animation-name: fold-left-in;
  animation-duration: 2s;
}
.fold-left-leave-active {
  animation-name: fold-left-out;
  animation-duration: 2s;
}
.fold-right-enter-active {
  animation-name: fold-right-in;
  animation-duration: 2s;
}
.fold-right-leave-active {
  animation-name: fold-right-out;
  animation-duration: 2s;
}
@keyframes fold-left-in {
  0% {
    transform: translate3d(100%, 0, 0);
  }
  100% {
    transform: translate3d(0, 0, 0);
  }
}
@keyframes fold-left-out {
  0% {
    transform: translate3d(0, 0, 0);
  }
  100% {
    transform: translate3d(-100%, 0, 0);
  }
}
</style>