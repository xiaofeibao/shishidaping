<!--
 * @Author: baoxiaofei
 * @Date: 2020-04-04 18:39:07
 * @LastEditors: baoxiaofei
 * @LastEditTime: 2020-04-07 13:17:19
 * @Description: 
 -->
<template>
	<div class="morning">
		<!--logo-->
		<div class="logo"></div>
		<!--20家机构登录情况轮播-->
		<!-- <LoginInfo /> -->
		<!-- <LoginNum /> -->
		<!--20家机构登录用户数柱状图-->
		<div class="left">
			<div class="login-list-title">核心交易商登录用户数</div>
			<div class="loginListChartLeft">
				<div class="tipCon">
          <span class="block"></span>
          <span class="tip">用户数</span>
        </div>
        <LoginListChart id="loginListChartId"/>
			</div>
		</div>
		<!-- 用户登录类型饼图（专线，互联网，api） -->
		<div class="right">
			<UserTypeChart class="loginListChartRight" id="userTypeChart" width="12.5rem" height="12.5rem" />
			<CurrentTime id="currentTime" width="12.5rem" height="12.5rem" />
		</div>
	</div>
</template>
<script>
// @ is an alias to /src
import LoginInfo from '@/components/LoginInfo.vue';
import LoginNum from '@/components/LoginNum.vue';
import UserTypeChart from '@/components/UserTypeChart.vue';
import LoginListChart from '@/components/LoginListChart.vue';
import CurrentTime from '@/components/CurrentTime.vue';

export default {
	name: 'Morning',
	components: {
		LoginInfo,
		UserTypeChart,
		LoginListChart,
		LoginNum,
		CurrentTime
	},
};
</script>
<style scoped lang="less">
.morning {
	position: absolute;
	background: url('../assets/bg.jpg') no-repeat center;
	background-size: 100% 100%;
	width: 100%;
	height: 100%;
	overflow: hidden;
	font-family: '微软雅黑';
	.left {
		width: 33%;
		height: 100%;
		position: relative;
		float: left;
	}
	.right {
		width: 33%;
		height: 100%;
		position: relative;
		float: right;
		color: #9fd2e3;
		font-size: 1rem;
	}
	.loginListChart {
		width: 80%;
		position: absolute;
		top: 18%;
		bottom: 15%;
	}
	.login-list-title {
		color: #fff;
		font-family: '微软雅黑';
		font-size: 1.5rem;
		position: absolute;
		top: 18%;
		bottom: 15%;
		right: 12%;
		left: 15%;
	}
	.loginListChartLeft {
		background: url('../assets/beforeLogin.png') no-repeat center;
		background-size: 100% 100%;
		.loginListChart;
		left: 10%;
		top: 21%;
		bottom: 13%;
	}
	.loginListChartRight {
		.loginListChart;
		right: 12%;
  }
  .tipCon {
    position: absolute;
    margin-top: 1.2rem;
    text-align: left;
    margin-left: 3.5rem;
    font-size: 1.05rem;
    .block {
      width: 1rem;
      height: 0.7rem;
      background-color: #0a265c;
      display: inline-block;
    }
    .tip {
      color: #9fd2e3;
      margin-left: 0.3rem;
    }
  }
}
</style>