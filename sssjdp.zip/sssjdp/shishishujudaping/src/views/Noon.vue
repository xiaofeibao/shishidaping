<!--
 * @Author: baoxiaofei
 * @Date: 2020-04-04 18:39:07
 * @LastEditors: baoxiaofei
 * @LastEditTime: 2020-04-07 13:17:46
 * @Description: 
 -->
<template>
	<div class="noon">
		<!--logo-->
		<div class="logo"></div>
		<!--20家机构登录用户数柱状图-->
		<div class="left">
			<div class="login-list-title">核心交易商首笔报价</div>
			<TheFirstQuotation />
		</div>
		<div class="left">
			<div class="login-list-title">核心交易商报价笔数</div>
			<DealListChart class="loginListChartLeft" id="dealListChartId" width="25rem" height="12.5rem" />
		</div>
		<!-- 用户登录类型饼图（专线，互联网，api） -->
		<div class="right">
			<UserTypeChart class="loginListChartRight" id="userTypeChart2" width="12.5rem" height="12.5rem" />
      		<CurrentTime id="currentTime" width="12.5rem" height="12.5rem" />
		</div>
	</div>
</template>

<script>
// @ is an alias to /src
import TheFirstQuotation from '@/components/TheFirstQuotation.vue';
import QuotationCount from '@/components/QuotationCount.vue';
import UserTypeChart from '@/components/UserTypeChart.vue';
import DealListChart from '@/components/DealListChart.vue';
import CurrentTime from '@/components/CurrentTime.vue';

export default {
	name: 'Noon',
	components: {
		TheFirstQuotation,
		QuotationCount,
		UserTypeChart,
		DealListChart,
		CurrentTime
	},
};
</script>
<style scoped lang="less">
.noon {
	position: absolute;
	background: url('../assets/bg.jpg') no-repeat center;
	background-size: 100% 100%;
	width: 100%;
	height: 100%;
	overflow: hidden;
}
.left {
	width: 33%;
	height: 100%;
	position: relative;
	float: left;
}
.right {
	width: 33%;
	height: 100%;
	position: relative;
	float: right;
	color: #9fd2e3;
	font-size: 1rem;
}
.loginListChart {
	width: 80%;
	position: absolute;
	top: 18%;
	bottom: 15%;
}
.login-list-title {
	color: #fff;
	font-family: '微软雅黑';
	position: absolute;
	font-size: 1.5rem;
	top: 18%;
	bottom: 15%;
	right: 12%;
	left: 15%;
}
.loginListChartLeft {
	background: url('../assets/beforeLogin.png') no-repeat center;
	background-size: 100% 100%;
	.loginListChart;
	left: 10%;
	top: 21%;
	bottom: 13%;
}
.loginListChartRight {
	.loginListChart;
	right: 12%;
}
</style>