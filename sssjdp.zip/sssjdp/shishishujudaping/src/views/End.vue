<template>
	<div class="end">
		<div class="thanks">谢谢观看！</div>
		<CurrentTime id="currentTime" class="time" width="12.5rem" height="12.5rem" />
	</div>
</template>

<script>

import CurrentTime from '@/components/CurrentTime.vue';
export default {
	name: 'End',
	components: {
		CurrentTime
	},
};
</script>
<style scoped lang="less">
.end {
	position: absolute;
	background: url('../assets/bg.jpg') no-repeat center;
	background-size: 100% 100%;
	width: 100%;
	height: 100%;
	overflow: hidden;
	text-align: center;
}
.thanks {
	font-size: 5rem;
    color: #fff;
    margin-top: 22%;
}
.time {
  color: #fff;
  font-family: Arial, Black;
  font-size: 1.875rem;
  font-weight: bold;
  position: absolute;
  bottom: 4%;
  right: 5%;
  letter-spacing: 0.2rem;
}
</style>
