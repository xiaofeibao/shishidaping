<template>
  <div class="afternoon">
    <!--logo-->
    <div class="logo"></div>
    <!--20家机构登录用户数柱状图-->
    <div class="left">
	  <!--交易热榜-->
	  <div class="login-list-title">交易产品热榜</div>
      <div class="hot-trading-con">
		<HotTrading />
      </div>
    </div>
    <div class="left">
		<!--交易总量-->
		<TheTotalTradeVolume />
		<News v-if="showNews"/>
		<CompareData v-if="!showNews"/>
		<div class="bottomChart clear" v-if="showNews">
			<!--成交笔数饼图-->
			<TransationAmountChart id="amountChart" width="10rem" height="10rem" />
			<!--成交量饼图-->
			<TheTotalTradeVolumeChart id="tradeChart" width="10rem" height="10rem" />
			<div class="chartColorTip">
				<div class="crpoT">
					<span class="market crpoM"></span>
					<span class="marketNm ">质押式回购</span>
				</div>
				<div class="cbtT">
					<span class="market cbtM"></span>
					<span class="marketNm ">现券买卖</span>
				</div>
				<div class="irsT">
					<span class="market irsM"></span>
					<span class="marketNm ">利率互换</span>
				</div>
				<div class="sirsT">
					<span class="market sirsM"></span>
					<span class="marketNm ">标准利率互换</span>
				</div>
				<div class="sbfT">
					<span class="market sbfM"></span>
					<span class="marketNm ">标准债券远期</span>
				</div>
			</div>
		</div>
		<!--成交数据对比-->
		<!-- <ActiveInstitution /> -->
    </div>
    <!-- 成交数据对比柱状图 -->
    <div class="right">
	  <div class="active-list-title-right">活跃机构榜</div>
	  <div class="activeListChartRight">
		<div class="chartId1">
			<div class="chartTitle clear">
				<span class="market">质押式回购</span>
				<span class="tip">成交笔数</span>
				<span class="crpoblock"></span>
				<span class="tip">交易金额(亿元)</span>
				<span class="crpoVolblock"></span>
			</div>
			<ComparedChart id="comparedChartId"/>
		</div>
		<div class="chartId1">
			<div class="chartTitle clear">
				<span class="market">现券买卖</span>
				<span class="tip">交易金额(亿元)</span>
				<span class="cbtVolblock"></span>
				<span class="tip">成交笔数</span>
				<span class="cbtblock"></span>
			</div>
			<ComparedCbtChart id="comparedCbtChartId"/>
		</div>
		<div class="chartId1">
			<div class="chartTitle ">
				<span class="market">利率互换</span>
				<span class="tip">交易金额(亿元)</span>
				<span class="irsVolblock"></span>
				<span class="tip">成交笔数</span>
				<span class="irsblock"></span>
			</div>
			<ComparedIrsChart id="comparedIrsChartId"/>
		</div>
	  </div>
	  <LoginList class="loginListRight" id="loginList" width="12.5rem" height="12.5rem" />
      <CurrentTime id="currentTime" width="12.5rem" height="12.5rem" />
    </div>
  </div>
</template>
<script lang="ts">
// @ is an alias to /src
import HotTrading from '@/components/HotTrading.vue';
import TheTotalTradeVolume from '@/components/TheTotalTradeVolume.vue';
import TheTotalTradeVolumeChart from '@/components/TheTotalTradeVolumeChart.vue';
import ActiveInstitution from '@/components/ActiveInstitution.vue';
import News from '@/components/News.vue';
import TransationAmountChart from '@/components/TransationAmountChart.vue';
import ComparedChart from '@/components/ComparedChart.vue';
import ComparedCbtChart from '@/components/ComparedCbtChart.vue';
import ComparedIrsChart from '@/components/ComparedIrsChart.vue';
import LoginList from '@/components/LoginList.vue';
import CurrentTime from '@/components/CurrentTime.vue';
import CompareData from '@/components/CompareData.vue';
import Vue from "vue";
import { createNamespacedHelpers } from "vuex";
const { mapState, mapActions } = createNamespacedHelpers("currentTime");
const comparedChartStore = createNamespacedHelpers("comparedChart");
const marketDataStore = createNamespacedHelpers("theTotalTradeVolume");
export default {
	name: 'Afternoon',
	data: function() {
		return {
			intercal: 0,
			showNews: true
		}
	},
	created: function() {
		this.interval = setInterval(() => {
			this.getComparedChart();
			this.getTotalTradeVolume();
		}, 1000)
	},
	beforeDestroy: function() {
		if(this.interval) {
			clearInterval(this.interval)
		}
	},
	components: {
		HotTrading,
		TheTotalTradeVolume,
		TheTotalTradeVolumeChart,
		ActiveInstitution,
		News,
		TransationAmountChart,
		ComparedChart,
		ComparedCbtChart,
		ComparedIrsChart,
		LoginList,
		CurrentTime,
		CompareData
	},
	computed: {
		...mapState({
			data: state => state.oriTime
		})
	},
	methods:  {
		//在‘hotTrading数据模块‘中查找并绑定方法
		...comparedChartStore.mapActions(['getComparedChart']),
		...marketDataStore.mapActions(['getTotalTradeVolume']),
	},
	watch: {
		data(e) {
			let time = new Date(e);
			let str = time.getFullYear()+ '/'+ (time.getMonth()+1)+'/'+time.getDate();
			if(time < new Date(str+' 17:30:00')){   
				this.showNews = true;
			}else if(time > new Date(str+' 17:30:00')){
				this.showNews = false;
			}
		}
	}
};
</script>
<style scoped lang="less">
.fl {
	float: left;
}
.textOverflow {
	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;
}
.afternoon {
	position: absolute;
	background: url('../assets/bg.jpg') no-repeat center;
	background-size: 100% 100%;
	width: 100%;
	height: 100%;
	overflow: hidden;
}
.left {
  width: 33%;
  height: 100%;
  position: relative;
  float: left;
}
.hot-trading-con {
  position: absolute;
  top: 18%;
  bottom: 10%;
  right: 15%;
  left: 12%;
  padding-top: 0.625rem;
}
.loginListChart {
	width: 80%;
	position: absolute;
	top: 18%;
	bottom: 10%;
}
.login-list-title {
	color: #fff;
	font-family: '微软雅黑';
	position: absolute;
	font-size: 1.5rem;
	top: 15%;
	right: 15%;
	left: 12%;
}
.active-list-title-right {
	.login-list-title;
	top: 15%;
}
.activeListChartRight {
	background: url('../assets/beforeLogin.png') no-repeat center;
	background-size: 100% 100%;
	.loginListChart;
	right: 12%;
	padding-top: 0.625rem;
	top: 19.4%;
	bottom: 7.5%;
}
.loginListRight {
	width: 80%;
	position: absolute;
	top: 18%;
    right: -24%;
    top: 3%;
}
.chartId1 {
	height: 33.3%;
}
.market {
	float: left;
	margin-left: 15%;
    margin-top: 4%;
    font-size: 1.25rem;
}
.block {
	float: right;
	width: 1.25rem;
	height: 0.625rem;    
	margin-right: 0.3125rem;
    margin-top: 5.8%;
}
.crpoblock {
	.block;
	background: linear-gradient(to right,#bba749,#dec652, #f9e068,#fdff4a);
}
.crpoVolblock {
	.block;
	background: linear-gradient(to right,#0c265c,#0568a7, #03aada,#00e3fb);

}
.cbtblock {
	.block;
	background: linear-gradient(to right,#483f3f,#806f50, #d1b161,#f4ce69);

}
.cbtVolblock {
	.block;
	background: linear-gradient(to right,#6f2025,#a7313c, #ef4858,#ef4858);
}
.irsblock {
	.block;
	background: linear-gradient(to right,#3b275d,#703d94,#b55ad6,#d766f5);

}
.irsVolblock {
	.block;
	background: linear-gradient(to right,#253b8c,#2a44a2, #2a4dd4,#2f56ec);
}
.tip {
	float: right;
    margin-right: 8%;
    margin-top: 5%;
    font-size: 0.75rem;
}
.right {
  width: 33%;
  height: 100%;
  position: relative;
  float: right;
  color: #9fd2e3;
  font-size: 1rem;
}
.chartColorTip {
	background: url('../assets/dealChart.png') no-repeat center;
	background-size: 100% 100%;
    width: 90%;
    height: 20%;
    position: absolute;
    left: 5%;
    bottom: 23%;
    padding-top: 1.6rem;
    padding-left: 0.625rem;
    padding-right: 0.625rem;
	.market {
		width: 1rem;
		height: 0.625rem;
		display: inline-block;
		vertical-align: middle;
	}
	.crpoT,
	.cbtT,
	.irsT,
	.sirsT,
	.sbfT {
		.fl;
		.textOverflow;
	}
	.crpoT {
		width: 20%;
	}
	.cbtT,
	.irsT {
		width: 16%;
	}
	.sirsT,
	.sbfT {
		width: 24%;
	}
	.crpoM {
		.market;
		background-color: #27f8fc;
	}
	.cbtM {
		.market;
		background-color: #f5cc6c;
	}
	.irsM {
		.market;
		background-color: #9b47fd;
	}
	.sirsM {
		.market;
		background-color: #f86271;
	}
	.sbfM {
		.market;
		background-color: #5277ff;
	}
	.marketNm {
		font-size: 0.7rem;
		margin-left: 0.3rem;
	}
}
.bottomChart {
	position: relative;
	height: 33.3%;
	color: #9fd2e3;
}
.chartTitle {
	margin-bottom: 0rem;
}
</style>