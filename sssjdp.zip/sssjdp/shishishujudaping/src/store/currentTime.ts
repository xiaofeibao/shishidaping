import axios from 'axios';
/**
 * 获取当前时间
 */
export const CurrentTimeModule = {
	namespaced: true,
	state: {
		data: '', //显示时间 HH:MM:SS
		oriTime:'',//原始时间戳
		inSearch: false
	},
	mutations: {
		increment(state: any) {
			if(state.oriTime) {
				let time = new Date(state.oriTime);
				let str = (time.getHours()<10? '0'+time.getHours():time.getHours())+ ':'+
					(time.getMinutes()<10? '0'+time.getMinutes():time.getMinutes()) + ':'+
					(time.getSeconds()<10? '0'+time.getSeconds():time.getSeconds());
				state.data = str;
			}
		},
	},
	actions: {
		getCurrentTime({ state, commit }) {
			if(state.inSearch == false) {
				state.inSearch = true
			
				axios.post('/tbs/hawk/rest/tbs-ur-hawk/getTime').then((response) => {
					state.oriTime = response.data.data.result;
					state.inSearch = false
					commit('increment');
				}).catch(() => {
					state.inSearch = false
				});
			}
		}
	},
};
