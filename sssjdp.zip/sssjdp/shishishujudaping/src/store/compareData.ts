import axios from 'axios';
/**
 * 获取当前时间
 */
export const CompareDataModule = {
	namespaced: true,
	state: {
		data: {},
		inSearch: false
	},
	mutations: {
		increment(state: any) {
			state.data.forEach(item => {
				if(item.market =='CBT') {
					state.data.cbtData = item;
				}else if(item.market =='CRPO') {
					state.data.crpoData = item;
				}else if(item.market =='IRS') {
					state.data.irsData = item;
				}else if(item.market =='SIRS') {
					state.data.sirsData = item;
				}else if(item.market =='SBF') {
					state.data.sbfData = item;
				}
			});
		},
	},
	actions: {
		getCompareData({ state, commit }) {
			if(state.inSearch == false) {
				state.inSearch = true;
				axios.post('/tbs/hawk/rest/tbs-ur-hawk/compareData').then((response) => {
					state.data = response.data.data.result;
					state.inSearch = false
					commit('increment');
				}).catch(() => {
					state.inSearch = false;
				});
			}
		},
		addCount(context: any) {
			context.commit('increment');
		},
	},
};
