import axios from 'axios'
/**
 * 20家机构登录用户数柱状图
 */
export const DealListChartModule = {
  namespaced: true,
  state: {
    // 质押式回购
    crList: [],
    // 线圈买卖
    cbtList: [],
    // 利率互换
    irsList: [],
    inSearch: false
  },
  mutations: {
    getDealList (state: any, payload: any){
      state.crList=payload.crList,
      state.cbtList = payload.cbtList,
      state.irsList = payload.irsList
    }
  },
  actions: {
    getDealListChart (context: any) {
      if(context.state.inSearch == false) {
        context.state.inSearch = true
      
        axios
          .post('/tbs/hawk/rest/tbs-ur-hawk/instnQuoteNo')
          .then(response => {
            const results = response.data.data.result;
            let crList:Array<any> = [],cbtList:Array<any> = [],irsList:Array<any> = [];
            results.forEach((e: any) => {
              const instnNm = context.rootState.instiCodeNmList.find((ee: any)=>ee.instiCode == e.instnCode).instiNm;
              crList.push([e.crNo,instnNm]);
              cbtList.push([e.cbtNo,instnNm]);
              irsList.push([e.irsNo, instnNm]);
              // crList.push([Math.random()*100, instnNm]);
              // cbtList.push([Math.random()*100, instnNm]);
              // irsList.push([Math.random()*100, instnNm]);
            });
            crList.reverse();
            cbtList.reverse();
            irsList.reverse();
            context.state.inSearch = false
            context.commit('getDealList',{
              crList,
              cbtList,
              irsList
            });
            // context.state.crList = crList;
            // context.state.cbtList = cbtList;
            // context.state.irsList = irsList;
          }).catch(() => {
            context.state.inSearch = false
          })
      }
    }
  }
}
