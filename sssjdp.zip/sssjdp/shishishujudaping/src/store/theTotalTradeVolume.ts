import axios from 'axios'
/**
 * 交易总量文字
 */
export const TheTotalTradeVolumeModule = {
  namespaced: true,
  state: {
    loginList: [],
    count: 0,
    data: {},
    inSearch: false
  },
  mutations: {
    addLogin (state: any, loginList: []) {
      state.loginList.push(...loginList)
    },
    increment (state: any) {
      //转成千分位显示
      let reg = /\d{1,3}(?=(\d{3})+$)/g;
      let val = state.data.volAll.toString();
      if (val != '—') {
          if (val.indexOf(".") > -1) {//有小数
              let num = val.split(".");
              let integer = num[0].replace(reg, '$&,');
              let res = integer + "." + num[1];
              state.data.volAll = res;
          } else {                   //是整数
            state.data.volAll = val.replace(reg, '$&,');
          }
      } else {
        state.data.volAll = '—';
      }
    }
  },
  actions: {
    getTotalTradeVolume ({ state, commit }) {
      let params = {
        no: state.data.dealNoAll?state.data.dealNoAll.toString():''
      }
      if(state.inSearch == false) {
        state.inSearch = true
        axios.post('/tbs/hawk/rest/tbs-ur-hawk/marketData',params).then((response) => {
            state.data = response.data.data.result
            // state.data = {
            //   "time": "09:00:06",
            //   "volAll":100000.12,
            //   "dealNoAll":500,
            //   "peak":"400",
            //   list:[{
            //     "market":"CBT",
            //     "vol":10000,
            //     "no":5
            //   },{
            //     "market":"CRPO",
            //     "vol":10000,
            //     "no":5  
            //   },{
            //     "market":"IRS",
            //     "vol":10000,
            //     "no":5  
            //   },{
            //     "market":"SIRS",
            //     "vol":10000,
            //     "no":5  
            //   },{
            //     "market":"SBF",
            //     "vol":10000,
            //     "no":5  
            //   }]
            // }
            state.inSearch = false
            commit('increment')
          }).catch(()=>{
            state.inSearch = false
          })
        }
    },
    addCount ({ commit }) {
      commit('increment')
    }
  }
}
