import axios from 'axios'
/**
 * 成交量饼图
 */
export const TheTotalTradeVolumeChartModule = {
  namespaced: true,
  state: {
    loginList: [],
    count: 0,
    data: {
      time: {
        updated: ''
      }
    },
    inSearch: false
  },
  mutations: {
    addLogin (state: any, loginList: []) {
      state.loginList.push(...loginList)
    },
    increment (state: any) {
    }
  },
  actions: {
    getData ({ state, commit }) {
      let params = {
        no: state.data.dealNoAll?state.data.dealNoAll.toString():''
      }
      if(state.inSearch == false) {
        state.inSearch = true
        axios.post('/tbs/hawk/rest/tbs-ur-hawk/marketData',params).then((response) => {
          state.data = response.data.data.result
          state.inSearch = false
          commit('increment')
        }).catch(()=>{
          state.inSearch = false
        })
      }
    },
    addCount ({ commit }) {
      commit('increment')
    }
  }
}
