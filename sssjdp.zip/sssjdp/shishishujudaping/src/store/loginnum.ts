import axios from 'axios'
/**
 * 登录情况文字版模型
 */
export const LoginNumModule = {
  namespaced: true,
  state: {
    // 登录情况文字版
    hotTradingList: [],
    data: {
      time: {
        updated: ''
      },
      inSearch: false
    }
  },
  mutations: {
    addLogin (state: any, loginList: []) {
      state.loginList.push(...loginList)
    },
    increment (state: any) {
      // console.log(state.data)
      for(let index in state.data.result.crpo){
        if(index == '0'){//回购市场第一个产品展示5位笔数
          state.data.result.crpo[index].dlNo = (Array(5).join(0) + state.data.result.crpo[index].dlNo).slice(-5);
        }else{
          state.data.result.crpo[index].dlNo = (Array(3).join(0) + state.data.result.crpo[index].dlNo).slice(-3);
        }
      }
      for(let index in state.data.result.cbt){//现券4位
          state.data.result.cbt[index].dlNo = (Array(4).join(0) + state.data.result.cbt[index].dlNo).slice(-4);
      }
      for(let index in state.data.result.irs){//利率互换4位
        state.data.result.irs[index].dlNo = (Array(4).join(0) + state.data.result.irs[index].dlNo).slice(-4);
      }
    }
  },
  actions: {
    getHotTrading ({ state, commit }) {
      if(state.inSearch == false) {
        state.inSearch = true
      
        axios
          .get('https://api.coindesk.com/v1/bpi/currentprice.json')
          .then(response => {
            state.data = {
              "result": {
                  "crpo": [
                      {
                          "show": "R2M",
                          "dlNo": 200
                      },
                      {
                          "show": "R014",
                          "dlNo": 9
                      },
                      {
                          "show": "R001",
                          "dlNo": 8
                      }
                  ],
                  "cbt": [
                      {
                          "show": "zllyp",
                          "dlNo": 1
                      }
                  ],
                  "irs": [
                      {
                          "show": "FR001_6D",
                          "dlNo": 1
                      },
                      {
                          "show": "FR007_7D",
                          "dlNo": 1
                      },
                      {
                          "show": "Shibor_1M_7D",
                          "dlNo": 1
                      }
                  ]
              }
            }
            // state.data = response.data
            commit('increment')
          }).catch(()=>{
            state.inSearch = false;
          })
        }
    },
    addCount (context: any) {
      context.commit('increment')
    }
  }
}
