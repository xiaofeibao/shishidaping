import axios from 'axios'
/**
 * 登录信息模型
 */
export const LoginInfoModule = {
  namespaced: true,
  state: {
    // 登录信息列表（20 加主要机构）
    loginList: [],
    count: 0,
    data: {
      time: {
        updated: ''
      },
      inSearch: false
    }
  },
  mutations: {
    addLogin (state: any, loginList: []) {
      state.loginList.push(...loginList)
    },
    increment (state: any) {
      state.count++
      const codeList = ['100010', '100035', '100002']
      const resList: Array<string> = new Array<string>()
      codeList.forEach(item => {
        // rootState.instiCodeNmList.forEach(subItem => {
        //   if (subItem.instiCode === item) {
        //     resList.push(subItem.instiNm)
        //   }
        // })
      })
      state.data = resList
    }
  },
  actions: {
    getData ({ state, commit }) {
      if(state.inSearch == false) {
        state.inSearch = true;
      
        axios
          .get('https://api.coindesk.com/v1/bpi/currentprice.json')
          .then(response => {
            state.data = response.data;
            state.inSearch = false;

            commit('increment')
          }).catch(() => {
            state.inSearch = false;
          })
        }
    },
    addCount ({ commit }) {
      commit('increment')
    }
  }
}
