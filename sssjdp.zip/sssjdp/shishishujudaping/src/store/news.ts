/*
 * @Author: your name
 * @Date: 2020-04-07 13:28:07
 * @LastEditTime: 2020-04-07 16:46:18
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \screen\src\store\news.ts
 */
import axios from 'axios'
/**
 * 新闻列表
 */
export const NewsModule = {
  namespaced: true,
  state: {
    loginList: [],
    count: 0,
    data: {
      cbtNew: String,
      crpoNew: String,
      irsNew: String,
      sirsNew: String,
      sbfNew: String
    },
    inSearch: false
  },
  mutations: {
    // addLogin (state: any, loginList: []) {
    //   state.loginList.push(...loginList)
    // },
    newsIncrement (state: any) {
      state.data.forEach(item => {
        let str = `${item.byrName?item.byrName:''}和
          ${item.slrName?item.slrName:''}
          ${item.dlTm?item.dlTm:''}达成`;
        let lastStr: String = '';
        if(item.dlNo == '1'){
          lastStr = `首笔${item.qtTp?item.qtTp:''}成交`;
        }else {
          lastStr = `第${item.dlNo}笔成交`;
        }

        switch (item.market) {
          case 'CBT':
            state.data.cbtNew = str+'现券买卖'+lastStr;
            break;
          case 'CRPO':
            state.data.crpoNew = str+'质押式回购'+lastStr;
            break;
          case 'IRS':
            state.data.irsNew = str+'利率互换'+lastStr;
            break;
          case 'SIRS':
            state.data.sirsNew = str+'标准利率互换'+lastStr;
            break;
          case 'SBF':
            state.data.sbfNew = str+'标准债券远期'+lastStr;
            break;
          default:
            break;
        }
      });
    }
  },
  actions: {
    getNewsData ({ state, commit }) {
      if(state.inSearch == false) {
        state.inSearch = true
        axios
          .post('/tbs/hawk/rest/tbs-ur-hawk/marketNewsData')
          .then(response => {
            state.data = response.data.data.result
            state.inSearch = false
            commit('newsIncrement')
          }).catch(()=>{
            state.inSearch = false
          })
        }
    }
  }
}
