import axios from 'axios'
/**
 * 20家机构登录用户数柱状图
 */
export const LoginListChartModule = {
  namespaced: true,
  state: {
    loginList: [],
    inSearch: false
  },
  mutations: {
    getLoginList (state: any, loginList: Array<any>){
      state.loginList = loginList
    }
  },
  actions: {
    getLoginListChart (context: any) {
      if(context.state.inSearch == false) {
        context.state.inSearch = true
        axios
          .post('/tbs/hawk/rest/tbs-ur-hawk/instnLoginData')
          .then(response => {
            const results = response.data.data.result;
            let loginList:Array<any> = [];
            context.rootState.instiCodeNmList.forEach((e: any) => {
              results.forEach((item: any) => {
                if(e.instiCode == item.instnCode) {
                  loginList.push([item.userCount,e.instiNm])
                }
              });
            });
            loginList.reverse();
            context.state.inSearch = false
            context.commit('getLoginList',loginList)
          }).catch(() => {
            context.state.inSearch = false
          })
      }
    }
  }
}
