import Vue from 'vue'
import Vuex from 'vuex'
import { ActiveInstitutionModule } from './activeInstitution'
import { ComparedChartModule } from './comparedChart'
import { ComparedCbtChartModule } from './comparedCbtChart'
import { ComparedIrsChartModule } from './comparedIrsChart'
import { LoginInfoModule } from './logininfo'
import { HotTradingModule } from './hottrading'
import { NewsModule } from './news'
import { QuotationCountModule } from './quotationCount'
import { TheFirstQuotationModule } from './theFirstQuotation'
import { TheTotalTradeVolumeModule } from './theTotalTradeVolume'
import { TheTotalTradeVolumeChartModule } from './theTotalTradeVolumeChart'
import { TransationAmountChartModule } from './transationAmountChart'
import { UserTypeChartModule } from './userTypeChart'
import { LoginNumModule } from './loginnum'
import { LoginListChartModule } from './loginListChart'
import { DealListChartModule } from './dealListChart'
import { CurrentTimeModule } from './currentTime'
import { CompareDataModule } from './compareData'
import Axios from 'axios'
Vue.use(Vuex)
Axios.defaults.baseURL = "http://199.31.219.171:30000"
export default new Vuex.Store({
  state: {
    instiCodeNmList: [
      {
        instiCode: '100003',
        instiFullNm: '中国农业银行股份有限公司',
        instiNm: '农业银行'
      },
      {
        instiCode: '100034',
        instiFullNm: '国家开发银行',
        instiNm: '国开行'
      },
      {
        instiCode: '100013',
        instiFullNm: '平安银行股份有限公司',
        instiNm: '平安银行'
      },
      {
        instiCode: '100011',
        instiFullNm: '上海浦东发展银行股份有限公司',
        instiNm: '浦发银行'
      },
      {
        instiCode: '100014',
        instiFullNm: '兴业银行股份有限公司',
        instiNm: '兴业银行'
      },
      {
        instiCode: '100009',
        instiFullNm: '中国光大银行股份有限公司',
        instiNm: '光大银行'
      },
      {
        instiCode: '100008',
        instiFullNm: '招商银行股份有限公司',
        instiNm: '招商银行'
      },
      {
        instiCode: '100007',
        instiFullNm: '中信银行股份有限公司',
        instiNm: '中信银行'
      },
      {
        instiCode: '100010',
        instiFullNm: '华夏银行股份有限公司',
        instiNm: '华夏银行'
      },
      {
        instiCode: '100035',
        instiFullNm: '中信证券股份有限公司',
        instiNm: '中信证券'
      },
      {
        instiCode: '101891',
        instiFullNm: '浙商银行股份有限公司',
        instiNm: '浙商银行'
      },
      {
        instiCode: '100001',
        instiFullNm: '中国工商银行股份有限公司',
        instiNm: '工商银行'
      },
      {
        instiCode: '100002',
        instiFullNm: '中国银行股份有限公司',
        instiNm: '中国银行'
      },
      {
        instiCode: '101747',
        instiFullNm: '中国邮政储蓄银行股份有限公司',
        instiNm: '邮储银行'
      },
      {
        instiCode: '100051',
        instiFullNm: '上海银行股份有限公司',
        instiNm: '上海银行'
      },
      {
        instiCode: '100015',
        instiFullNm: '中国民生银行股份有限公司',
        instiNm: '民生银行'
      },
      {
        instiCode: '100005',
        instiFullNm: '交通银行股份有限公司',
        instiNm: '交通银行'
      },
      {
        instiCode: '100012',
        instiFullNm: '广发银行股份有限公司',
        instiNm: '广发银行'
      },
      {
        instiCode: '100004',
        instiFullNm: '中国建设银行股份有限公司',
        instiNm: '建设银行'
      },
      {
        instiCode: '100653',
        instiFullNm: '宁波银行股份有限公司',
        instiNm: '宁波银行'
      }
    ]
  },
  mutations: {
  },
  actions: {
  },
  modules: {
    loginInfo: LoginInfoModule,
    hotTrading: HotTradingModule,
    activeInstitution: ActiveInstitutionModule,
    comparedChart: ComparedChartModule,
    comparedCbtChart: ComparedCbtChartModule,
    comparedIrsChart: ComparedIrsChartModule,
    news: NewsModule,
    quotationCount: QuotationCountModule,
    theFirstQuotation: TheFirstQuotationModule,
    theTotalTradeVolume: TheTotalTradeVolumeModule,
    theTotalTradeVolumeChart: TheTotalTradeVolumeChartModule,
    transationAmountChart: TransationAmountChartModule,
    userTypeChart: UserTypeChartModule,
    loginnum:LoginNumModule,
    loginListChart: LoginListChartModule,
    dealListChart: DealListChartModule,
    currentTime: CurrentTimeModule,
    compareData: CompareDataModule
  }
})
