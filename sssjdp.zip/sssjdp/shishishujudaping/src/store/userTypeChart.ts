import axios from 'axios'
/**
 * 用户登录类型饼图（专线，互联网，api）
 */
export const UserTypeChartModule = {
  namespaced: true,
  state: {
    loginList: [],
    count: 0,
    data: {
      time: {
        updated: ''
      }
    }
  },
  mutations: {
    addLogin (state: any, loginList: []) {
      state.loginList.push(...loginList)
    },
    increment (state: any) {
      state.count++
    }
  },
  actions: {
    getData ({ state, commit }) {
      axios
        .get('https://api.coindesk.com/v1/bpi/currentprice.json')
        .then(response => {
          state.data = response.data
          commit('increment')
        })
    },
    addCount ({ commit }) {
      commit('increment')
    }
  }
}
