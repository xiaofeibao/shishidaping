import axios from 'axios'
/**
 * 成交数据对比模型
 */
export const ActiveInstitutionModule = {
  namespaced: true,
  state: {
    // 成交数据对比
    loginList: [],
    count: 0,
    data: {
      time: {
        updated: ''
      }
    }
  },
  mutations: {
    addLogin (state: any, loginList: []) {
      state.loginList.push(...loginList)
    },
    increment (state: any) {
      state.count++
    }
  },
  actions: {
    getData ({ state, commit }) {
      axios
        .get('https://api.coindesk.com/v1/bpi/currentprice.json')
        .then(response => {
          state.data = response.data
          commit('increment')
        })
    },
    addCount ({ commit }) {
      commit('increment')
    }
  }
}
