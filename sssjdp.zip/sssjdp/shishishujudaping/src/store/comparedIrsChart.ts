import axios from 'axios'
/**
 * 成交数据对比柱状图
 */
export const ComparedIrsChartModule = {
  namespaced: true,
  state: {
    loginList: [],
    count: 0,
    resDataAxis: [],
    resLineData: [],
    data: {
      instiNmList:[],
      instiNumList:[],
      instiVolList:[]
    },
    inSearch: false
  },
  mutations: {
    addLogin (state: any, loginList: []) {
      state.loginList.push(...loginList)
    },
    increment (state: any) {
      let resNmList:Array<String> = [];
      let resNumList:Array<String> = [];
      let resVolList:Array<String> = [];
      if(state.data.irs && state.data.irs.length>0) {
        state.data.irs.forEach(item => {
          resNmList.push(item.instnNm);
          resVolList.push(item.trdvol);
          resNumList.push(item.dlNo);
        });
        state.data.instiNmList = resNmList;
        state.data.instiNumList = resNumList;
        state.data.instiVolList = resVolList;
      }
    }
  },
  actions: {
    getComparedIrsChart({ state, commit, rootState }) {
      if(state.inSearch == false) {
        state.inSearch = true
      
        axios.post('/tbs/hawk/rest/tbs-ur-hawk/instnHotList').then((response) => {
          state.data = response.data.data.result;
          state.inSearch = false
          commit('increment');
        }).catch(() => {
          state.inSearch = false
        });
      }
		},
    addCount ({ commit }) {
      commit('increment')
    }
  }
}
