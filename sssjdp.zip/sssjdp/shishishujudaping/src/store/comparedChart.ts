import axios from 'axios'
/**
 * 成交数据对比柱状图crpo
 */
export const ComparedChartModule = {
  namespaced: true,
  state: {
    loginList: [],
    count: 0,
    resDataAxis: [],
    resLineData: [],
    data: {
      instiNmList:[],
      instiNumList:[],
      instiVolList:[],
      crporesNmList:[],
      crporesNumList:[],
      crpoinstiVolList:[],
      irsresNmList:[],
      irsresNumList:[],
      irsinstiVolList:[]
    },
    inSearch: false
  },
  mutations: {
    addLogin (state: any, loginList: []) {
      state.loginList.push(...loginList)
    },
    increment (state: any) {
      let resNmList:Array<String> = [];
      let crporesNmList:Array<String> = [];
      let resNumList:Array<String> = [];
      let crporesNumList:Array<String> = [];
      let instiVolList:Array<String> = [];
      let crpoinstiVolList:Array<String> = [];
      let irsresNmList:Array<String> = [];
      let irsresVolList:Array<String> = [];
      let irsresNumList:Array<String> = [];
      if(state.data.crpo && state.data.crpo.length>0) {
        state.data.crpo.forEach(item => {
          crporesNmList.push(item.instnNm);
          crpoinstiVolList.push(item.trdvol);
          crporesNumList.push(item.dlNo);
        });
        state.data.crpoinstiNmList = crporesNmList;
        state.data.crpoinstiNumList = crporesNumList;
        state.data.crpoinstiVolList = crpoinstiVolList;
      }
      if(state.data.irs && state.data.irs.length>0) {
        state.data.irs.forEach(item => {
          irsresNmList.push(item.instnNm);
          irsresVolList.push(item.trdvol);
          irsresNumList.push(item.dlNo);
        });
        state.data.irsinstiNmList = irsresNmList;
        state.data.irsinstiNumList = irsresNumList;
        state.data.irsinstiVolList = irsresVolList;
      }
      if(state.data.cbt && state.data.cbt.length>0) {
        state.data.cbt.forEach(item => {
          resNmList.push(item.instnNm);
          instiVolList.push(item.trdvol);
          resNumList.push(item.dlNo);
        });
        state.data.nstiNmList = resNmList;
        state.data.instiNumList = resNumList;
        state.data.instiVolList = instiVolList;
      }
    }
  },
  actions: {
    getComparedChart({ state, commit, rootState }) {
      if(state.inSearch == false) {
        state.inSearch = true
      
			axios.post('/tbs/hawk/rest/tbs-ur-hawk/instnHotList').then((response) => {
        state.data = response.data.data.result;
        // let cbt:Array<any> = [],crpo:Array<any> = [], irs:Array<any> = [];
        // rootState.instiCodeNmList.slice(0,5).forEach((e: any) => {
        //   cbt.push({
        //     instnCd: e.instiCode,
        //     dlNo: Math.ceil(Math.random() * 200),
        //     trdvol: Math.ceil(Math.random() * 10000),
        //     instnNm: e.instiNm
        //   });
        //   crpo.push({
        //     instnCd: e.instiCode,
        //     dlNo: Math.ceil(Math.random() * 200),
        //     trdvol: Math.ceil(Math.random() * 10000),
        //     instnNm: e.instiNm
        //   });
        //   irs.push({
        //     instnCd: e.instiCode,
        //     dlNo: Math.ceil(Math.random() * 200),
        //     trdvol: Math.ceil(Math.random() * 10000),
        //     instnNm: e.instiNm
        //   });
        // });
        // state.data = {
        //   cbt,
        //   crpo,
        //   irs
        // }
        state.inSearch = false;
				commit('increment');
			}).catch(() => {
        state.inSearch = false;
      });
    }
		},
    addCount ({ commit }) {
      commit('increment')
    }
  }
}
