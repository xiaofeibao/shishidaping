import axios from 'axios'
/**
 * 20家机构第一次报价信息轮播
 */
export const TheFirstQuotationModule = {
  namespaced: true,
  state: {
    loginList: [],
    count: 0,
    data: {
      time: {
        updated: ''
      }
    }
  },
  mutations: {
    addLogin (state: any, loginList: []) {
      state.loginList.push(...loginList)
    },
    increment (state: any) {
      state.count++
    }
  },
  actions: {
    getData ({ state, commit }) {
      axios
        .get('https://api.coindesk.com/v1/bpi/currentprice.json')
        .then(response => {
          state.data = response.data
          commit('increment')
        })
    },
    addCount ({ commit }) {
      commit('increment')
    }
  }
}
