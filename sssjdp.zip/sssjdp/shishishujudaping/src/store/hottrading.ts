import axios from 'axios';
/**
 * 交易热榜模型
 */
export const HotTradingModule = {
	namespaced: true,
	state: {
		// 三个市场交易产品热榜
		hotTradingList: [],
		data: {
			time: {
				updated: '',
			},
		},
	},
	mutations: {
		addLogin(state: any, hotTradingList: []) {
			state.hotTradingList.push(...hotTradingList);
		},
		increment(state: any) {
			// console.log(state.data);
			if(state.data.result.crpo.length>0){
				for (let index in state.data.result.crpo) {
					if (index == '0') {
						//回购市场第一个产品展示5位笔数
						state.data.result.crpo[index].dlNo = (Array(5).join(0) + state.data.result.crpo[index].dlNo).slice(
							-5
						);
					} else {
						state.data.result.crpo[index].dlNo = (Array(3).join(0) + state.data.result.crpo[index].dlNo).slice(
							-3
						);
					}
				}
			}
			if(state.data.result.cbt.length>0){
				for (let index in state.data.result.cbt) {
					//现券4位
					state.data.result.cbt[index].dlNo = (Array(4).join(0) + state.data.result.cbt[index].dlNo).slice(-4);
				}
			}
			if(state.data.result.irs.length>0){
				for (let index in state.data.result.irs) {
					//利率互换4位
					state.data.result.irs[index].dlNo = (Array(4).join(0) + state.data.result.irs[index].dlNo).slice(-4);
				}
			}
		},
	},
	actions: {
		getHotTrading({ state, commit }) {
			axios.post('/tbs/hawk/rest/tbs-ur-hawk/bondHotList').then((response) => {
				state.data = response.data.data;
				state.inSearch = false
				// state.data = {
				// 	"result": {
				// 		"crpo": [
				// 			{
				// 				"show": "R2M",
				// 				"dlNo": 200
				// 			},
				// 			{
				// 				"show": "R014",
				// 				"dlNo": 9
				// 			},
				// 			{
				// 				"show": "R001",
				// 				"dlNo": 8
				// 			}
				// 		],
				// 		"cbt": [
				// 			{
				// 				"show": "zllyp",
				// 				"dlNo": 1
				// 			}
				// 		],
				// 		"irs": [
				// 			{
				// 				"show": "FR001_6D",
				// 				"dlNo": 1
				// 			},
				// 			{
				// 				"show": "FR007_7D",
				// 				"dlNo": 1
				// 			},
				// 			{
				// 				"show": "Shibor_1M_7D",
				// 				"dlNo": 1
				// 			}
				// 		]
				// 	}
				// }
				commit('increment');
			}).catch(() => {
				state.inSearch = false;
			});
		},
		addCount(context: any) {
			context.commit('increment');
		},
	},
};
