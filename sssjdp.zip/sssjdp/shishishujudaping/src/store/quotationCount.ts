import axios from 'axios'
/**
 * 20家机构报价笔数柱状图
 */
export const QuotationCountModule = {
  namespaced: true,
  state: {
    loginList: [],
    count: 0,
    data: {
      time: {
        updated: ''
      }
    },
    inSearch: false
  },
  mutations: {
    addLogin (state: any, loginList: []) {
      state.loginList.push(...loginList)
    },
    increment (state: any) {
      state.count++
    }
  },
  actions: {
    getData ({ state, commit }) {
      if(state.inSearch == false) {
        state.inSearch = true
        axios
          .get('https://api.coindesk.com/v1/bpi/currentprice.json')
          .then(response => {
            state.data = response.data
            commit('increment')
          }).catch(()=>{
            state.inSearch = false
          });
        }
    },
    addCount ({ commit }) {
      commit('increment')
    }
  }
}
