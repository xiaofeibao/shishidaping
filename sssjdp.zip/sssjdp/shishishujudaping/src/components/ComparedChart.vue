<template>
  <div>
      <!-- 成交数据对比柱状图 -->
      <div id="comparedChartId">
      </div>
  </div>
</template>

<script lang="ts">
import { createNamespacedHelpers } from 'vuex'

const { mapState, mapActions } = createNamespacedHelpers('comparedChart')
export default {
  name: 'comparedChart',
  data: function () {
    return {
      interval: 0
    }
  },
  chart: null,
  mounted: function () {
    this.initChart();
  },
  methods: {
    // 在 `hotTrading 数据模块` 中查找并绑定方法
    initChart () {
      let dataAxis = this.data.crpoinstiNmList
      let data = this.data.crpoinstiNumList
      let voldata = this.data.crpoinstiVolList
      let yMax = 300
      let dataShadow = []
      let zoomSize = 1
      let options= { // 柱状图
        tooltip: { // 柱子遮罩提示
          trigger: 'axis',
          axisPointer: {            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
          }
        },
        grid: {  //图表margin
            left: '10%',
            right: '8%',
            bottom: '12%',
            top: '8%',
            containLabel: true
        },
        title: {
          // text: '特性示例：渐变色 阴影 点击缩放',
          // subtext: 'Feature Sample: Gradient Color, Shadow, Click Zoom'
        },
        xAxis: {
          data: dataAxis,
          axisLabel: {
            inside: false, //true ：横坐标字在柱子上
            textStyle: {
              color: '#9fd2e3', //横坐标文字颜色
              fontSize: '100%'
            },
            formatter(value,index) {
              if(value.length>4) {
                return value.substr(0,4)+"\n"+value.substr(4,4)+"\n"+value.substr(8)
              }else {
                return value
              }
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {//坐标
            show: true
          },
          z: 10
        },
        yAxis: {
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            textStyle: {
              color: '#9fd2e3',
              fontSize: '100%'
            }
          },
          splitLine: {//标线
            show: false
          },
        },
        dataZoom: [
          {
            type: 'inside'
          }
        ],
        series: [
          // { // For shadow
          //   type: 'bar',
          //   itemStyle: {
          //     color: 'rgba(0,0,0,0)'// 设置柱子背景阴影
          //   },
          //   barGap: '-100%',
          //   barCategoryGap: '40%',
          //   data: dataShadow,
          //   animation: false
          // },
          {
            type: 'bar',
            itemStyle: {
              color: new this.$echarts.graphic.LinearGradient(
                0, 0, 0, 1,
                [
                  { offset: 0, color: '#00e3fb' },//柱顶
                  { offset: 0.2, color: '#03aada' },
                  { offset: 0.5, color: '#0568a7' },
                  { offset: 1, color: '#0c265c' }// 柱底
                ]
              )
            },
            barMaxWidth: 20,
            emphasis: {
              itemStyle: {
                color: new this.$echarts.graphic.LinearGradient(
                  0, 0, 0, 1,
                  [
                    { offset: 0, color: '#00e3fb' },
                    { offset: 0.7, color: '#0568a7' },
                    { offset: 1, color: '#0c265c' }
                  ]
                )
              }
            },
            data: voldata
          },
          {
            type: 'bar',
            itemStyle: {
              color: new this.$echarts.graphic.LinearGradient(
                0, 0, 0, 1,
                [
                  { offset: 0.3, color: '#fdff4a' },//柱顶
                  { offset: 0.5, color: '#f9e068' },
                  { offset: 0.7, color: '#dec652' },
                  { offset: 0.8, color: '#bba749' }// 柱底
                ]
              )
            },
            barMaxWidth: 20,
            emphasis: {
              itemStyle: {
                color: new this.$echarts.graphic.LinearGradient(
                  0, 0, 0, 1,
                  [
                    { offset: 0, color: '#fdff4a' },//柱顶
                    { offset: 0.7, color: '#dec652' },
                    { offset: 1, color: '#bba749' }// 柱底
                  ]
                )
              }
            },
            data: data
          }
        ]
      }
      if(data && data.length>0){
      for (let i = 0; i < data.length; i++) {
        dataShadow.push(yMax)
      }
      }
      const ele = document.getElementById('comparedChartId')
      if(!this.chart) {
        this.chart = this.$echarts.init(ele)
      }
      if (options && typeof options === 'object') {
        this.chart.setOption(options, true)
      }
    }
  },
  computed: {
    ...mapState({
      count: state => state.count,
      loginList: state => state.loginList,
      data: state => state.data
    })
  },
  watch: {
    data(e) {
      this.initChart();
    }
  }
  // @Prop({ default: 'chart' }) private className!: string
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  #comparedChartId {
    height: 100%;
    width: 100%;
    position: relative;
    bottom:0px;
    font-size: 0.7rem;
  }
</style>