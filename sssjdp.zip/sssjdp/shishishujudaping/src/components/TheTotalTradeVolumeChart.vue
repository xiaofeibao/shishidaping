<template>
  <!-- 成交量饼图 -->
  <div class="chartCon">
    <div class="chartTip">成交量</div>
    <div
        class="fl"
        :id="id"
        :style="{height: height, width: width}"
    />
  </div>
</template>

<script lang="ts">
import { createNamespacedHelpers, mapState} from 'vuex'
import { Component, Vue, Prop, Watch } from 'vue-property-decorator'
import Axios from "axios";
@Component({
  computed: mapState('theTotalTradeVolume', [
    'data',
  ])
})
export default class TheTotalTradeVolumeChart extends Vue {
  // @Prop({ default: 'chart' }) private className!: string
	@Prop({ default: 'chart' }) private id!: string;
	@Prop({ default: '11.25rem' }) private width!: string;
	@Prop({ default: '11.25rem' }) private height!: string;
  public $echarts: any; // 圆环饼图
  private no: string = '';
  private interval = 0;
  private inSearch = false;
  private getData() {
    this.inSearch = true;
    let params = {
      no: this.no?this.no:''
    }
    Axios.post(
      "/tbs/hawk/rest/tbs-ur-hawk/marketData",params
    )
      .then(response => response.data.data)
      .then(data => {
        this.inSearch = false;
      }).catch(() => {
        this.inSearch = true;
      });
  }
  private chart: any;
  private initChart() {
    const result = this.data;
    const styleMap = [
      { name: 'CBT', itemStyle:{color:'#f5cc6b',} },
      { name: 'CRPO', itemStyle:{color:'#29faf9'} },
      { name: 'IRS', temStyle:{color:'#9c46fa'} },
      { name: 'SIRS', itemStyle:{color:'#f76271'} },
      { name: 'SBF', itemStyle:{color:'#5378ff'} }
    ];
    this.no = result.dealNoAll?result.dealNoAll:'';
    let dataObj = result.list.map((e: any) => {
      const itemStyle = styleMap.find((ee: any) => ee.name == e.market)
        .itemStyle;
      return {
        value: Number(e.vol),
        itemStyle
      };
    });
    const ele = document.getElementById(this.id)
    !this.chart && (this.chart = this.$echarts.init(ele))
    this.chart.setOption({
      tooltip: {
        trigger: 'item',
        formatter: '{c} ({d}%)'
      },
      series: [
        {
          name: '访问来源',
          type: 'pie',
          radius: ['70%', '85%'], // 圆环半径大小
          avoidLabelOverlap: false,
          label: {
            show: false,
            position: 'center'
          },
          emphasis: {
            label: {
              show: true,
              fontSize: '100%',
              fontWeight: 'bold'
            }
          },
          labelLine: {
            show: false
          },
          data: dataObj
        }
      ]
    });
    this.$forceUpdate();
  }
  @Watch('data')
  onPropertyChanged(value: any, oldValue: any) {
    this.initChart();
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .chartCon {
    -webkit-tap-highlight-color: transparent;
    user-select: none;
    position: relative;
    right: 20%;
    float: right;
    top: 5%;
  }
  .chartTip {
    font-family: '微软雅黑';
    font-size: 1.0625rem;
    position: relative;
    top: 5.8125rem;
  }
  .fl {
    float: left;
  }
</style>