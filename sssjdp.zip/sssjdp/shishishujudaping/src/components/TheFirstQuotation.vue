<template>
  <div class="con">
    <!--20家机构第一次报价信息轮播-->
    <div id="hideDiv" class="hideDiv"></div>
    <div id="firstQuoScrollBox">
      <ul id="firstQuoCon1" :style="{transform: 'translate(0,'+transformVal+'px)'}">
        <li
          v-for="(item,index) in quoteInfoList"
          :key="index"
          :style="{color: marketColorMap[item.market]}"
        >{{item.instnCdNm}}<span class="time">{{item.bsnsTm}}</span>发起{{marketMap[item.market]}}首笔{{getQtTp(item.market,item.qtTp)}}</li>
      </ul>
      <ul
        id="firstQuoCon2"
        :style="{transform: 'translate(0,'+ (-contentHeight + transformVal)+'px)'}"
      >
        <li
          v-for="(item,index) in quoteInfoList"
          :key="index"
          :style="{color: marketColorMap[item.market]}"
        >{{item.instnCdNm}}<span class="time">{{item.bsnsTm}}</span>发起{{marketMap[item.market]}}首笔{{getQtTp(item.market,item.qtTp)}}</li>
      </ul>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import Axios from "axios";

@Component
export default class TheFirstQuotation extends Vue {
  private quoteInfoList = [];
  private timer = 0;
  private marketMap = {
    CBT: "现券买卖",
    CRPO: "质押式回购",
    IRS: "利率互换",
    SIRS: "标准利率互换",
    SBF: "标准债券远期"
  };

  private marketColorMap = {
    CBT: "#f5cc6c",
    CRPO: "#27f8fc",
    IRS: "#9b47fd",
    SIRS: "#f86271",
    SBF: "#5277ff"
  }
  private inSearch = false;
  getQtTp(market, qtTp) {
    switch (qtTp) {
      case "RFQ请求":
        return "RFQ";
      case "集中匹配":
      case "连续匹配":
        if(qtTp=='连续匹配'&&market!=='CBT'){
          return 'X-Swap 订单'
        }
        return "X-Bond 订单";
      case "ESP报价(做市报价)":
        return "做市报价";
      default:
        return qtTp;
    }
  }

  created() {
    this.getFirstData();
    this.timer = setInterval(()=>{
      if(this.inSearch == false)  {
        this.getFirstData();
      }
    },1000);
  }

  private boxHeight = 0;

  private _transformVal = 0;

  private offsetVal = 0;

  private animation = 0;

  public get transformVal() {
    if (this.contentHeight > this.boxHeight) {
      this._transformVal = this.boxHeight - this.contentHeight + this.offsetVal;
    } else {
      this._transformVal = 0;
    }
    return this._transformVal;
  }

  public set transformVal(val) {
    this._transformVal = val;
  }

  private contentHeight = 0;

  getFirstData() {
    this.inSearch = true;
    Axios.post(
      "/tbs/hawk/rest/tbs-ur-hawk/instnQuoteFirstData"
    )
      .then(res => res.data.data)
      .then(data => {
        // console.log(data);
        // const isnts = ['招商银行','农业银行','工商银行','中国银行','中信银行','邮政储蓄','光大银行'];
        // const markets = ['CBT','CRPO','IRS','SIRS','SBF'];
        // let arr = [];
        // for(let i = 0;i < 20;i++){
        // 	arr.push({
        // 		instnCdNm: isnts[Math.floor(Math.random()*isnts.length)],
        // 		market: markets[Math.floor(Math.random()*markets.length)],
        // 		qtTp: 'RFQ',
        // 		bsnsTm: '09:34:33'
        // 	});
        // }
        // this.quoteInfoList = arr
        this.inSearch = false;
        this.quoteInfoList = data.result;
        this.contentHeight = this.quoteInfoList.length * document.getElementById("hideDiv").clientHeight;
        // console.log(this.contentHeight,this.boxHeight,this.transformVal);
      }).catch(()=>{
        this.inSearch = false;
      });
  }

  mounted() {
    const area = document.getElementById("firstQuoScrollBox");
    const firstQuoCon1 = document.getElementById("firstQuoCon1");
    const firstQuoCon2 = document.getElementById("firstQuoCon2");
    const hideDiv = document.getElementById("hideDiv");
    // const time = 40;
    // if (area) {
    // 	let mytimer = setInterval(function() {
    // 		if (area.scrollTop >= firstQuoCon1.offsetHeight) {
    // 			area.scrollTop = 0;
    // 		} else {
    // 			area.scrollTop++;
    // 		}
    // 	}, time);
    // 	firstQuoCon2.innerHTML = firstQuoCon1.innerHTML;

    // 	area.onmousemove = (e) => {
    // 		clearInterval(mytimer);
    // 	};

    // 	area.onmouseout = (e) => {
    // 		mytimer = setInterval(function() {
    // 			if (area.scrollTop >= firstQuoCon1.offsetHeight) {
    // 				area.scrollTop = 0;
    // 			} else {
    // 				area.scrollTop++;
    // 			}
    // 		}, time);
    // 	};
    // }

    this.boxHeight = area.clientHeight;
    this.contentHeight = this.quoteInfoList.length * hideDiv.clientHeight;
    this.animateContent();
  }

  animateContent() {
    this.animation = requestAnimationFrame(() => {
      if (this.contentHeight > this.boxHeight) {
        if (this.offsetVal >= this.contentHeight) {
          this.offsetVal -= this.contentHeight;
        }
        this.offsetVal += 0.4;
      }
      this.animateContent();
    });
  }

  beforeDestroy() {
    clearInterval(this.timer);
    cancelAnimationFrame(this.animation);
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
ul,
li {
  list-style: none;
  display: block;
}
/* .login-info {
        border: 1px solid red;
    } */
.con {
  background: url("../assets/beforeLogin.png") no-repeat center;
  background-size: 100% 100%;
  left: 10%;
  top: 21%;
  bottom: 13%;
  width: 80%;
  position: absolute;
  top: 21.5%;
  bottom: 11%;
}
#firstQuoScrollBox {
  overflow: hidden;
  color: #9fd2e3;
  position: absolute;
  padding-left: 3.125rem;
  text-align: left;
  top: 3.125rem;
  bottom: 3.125rem;
  width: 100%;
  box-sizing: border-box;
}
#firstQuoScrollBox #firstQuoCon1,
#firstQuoCon2 {
  /* width: 15.625rem; */
  /* float: left; */
  position: absolute;
  top: 0;
  width: 100%;
  padding-right: 4.25rem;
}
#firstQuoScrollBox li {
  height: 2.8125rem;
  line-height: 1.125rem;
}
.time {
  /* color: #fff;
  font-size: 1.1rem;
  margin-left: 0.3rem;
  margin-right: 0.3rem; */
}
.hideDiv {
  height: 2.8125rem;
  line-height: 1.125rem;
  position: absolute;
  right: -10rem;
  width: 3rem;
}
</style>