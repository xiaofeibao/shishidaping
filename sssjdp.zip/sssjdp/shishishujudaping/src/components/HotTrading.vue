<template>
  <div class="hotCon">
    <div class="crpoCon">
      <div class="hot-trading-title">
        质押式回购
      </div>
      <div class="clear">
				<div class="hot-trading-info fir-hot-info" v-if="data.result.crpo[0]">
					<div class="bondNm">{{data.result.crpo[0].show}}</div>
					<div class="dealNum">
            <div class="num crpoNum">{{data.result.crpo[0].dlNo.slice(0,1)}}</div>
            <div class="num crpoNum">{{data.result.crpo[0].dlNo.slice(1,2)}}</div>
            <div class="num crpoNum">{{data.result.crpo[0].dlNo.slice(2,3)}}</div> 
            <div class="num crpoNum">{{data.result.crpo[0].dlNo.slice(3,4)}}</div>
            <div class="num crpoNum">{{data.result.crpo[0].dlNo.slice(4,5)}}</div>
            <span class="numTip">笔</span>
          </div>
        </div>
        <div class="hot-trading-info fir-hot-info" v-else>
					<div class="bondNm2"></div>
					<div class="dealNum">
            <div class="num crpoNum">0</div>
            <div class="num crpoNum">0</div>
            <div class="num crpoNum">0</div> 
            <div class="num crpoNum">0</div>
            <div class="num crpoNum">0</div>
            <span class="numTip">笔</span>
          </div>
        </div>
				<div class="hot-trading-info sec-hot-info" v-if="data.result.crpo[1]">
				  <div class="bondNm">{{data.result.crpo[1].show}}</div>
					<div class="dealNum">
            <div class="num crpoNum">{{data.result.crpo[1].dlNo.slice(0,1)}}</div>
            <div class="num crpoNum">{{data.result.crpo[1].dlNo.slice(1,2)}}</div>
            <div class="num crpoNum">{{data.result.crpo[1].dlNo.slice(2,3)}}</div> 
            <span class="numTip">笔</span>
          </div>
        </div>
        <div class="hot-trading-info sec-hot-info" v-else>
					<div class="bondNm2"></div>
					<div class="dealNum">
            <div class="num crpoNum">0</div>
            <div class="num crpoNum">0</div>
            <div class="num crpoNum">0</div> 
            <span class="numTip">笔</span>
          </div>
        </div>
        <div class="hot-trading-info third-hot-info" v-if="data.result.crpo[2]">
          <div class="bondNm">{{data.result.crpo[2].show}}</div>
          <div class="dealNum">
            <div class="num crpoNum">{{data.result.crpo[2].dlNo.slice(0,1)}}</div>
            <div class="num crpoNum">{{data.result.crpo[2].dlNo.slice(1,2)}}</div>
            <div class="num crpoNum">{{data.result.crpo[2].dlNo.slice(2,3)}}</div> 
            <span class="numTip">笔</span>
          </div>
        </div>
        <div class="hot-trading-info third-hot-info" v-else>
					<div class="bondNm2"></div>
					<div class="dealNum">
            <div class="num crpoNum">0</div>
            <div class="num crpoNum">0</div>
            <div class="num crpoNum">0</div> 
            <span class="numTip">笔</span>
          </div>
        </div>
			</div>
		</div>
    <div class="cbtCon">
      <div class="hot-trading-title">
        现券买卖
      </div>
      <div class="clear">
				<div class="hot-trading-info fir-hot-info" v-if="data.result.cbt[0]">
					<div class="bondNm">{{data.result.cbt[0].show}}</div>
					<div class="dealNum">
            <div class="num cbtNum">{{data.result.cbt[0].dlNo.slice(0,1)}}</div>
            <div class="num cbtNum">{{data.result.cbt[0].dlNo.slice(1,2)}}</div>
            <div class="num cbtNum">{{data.result.cbt[0].dlNo.slice(2,3)}}</div> 
            <div class="num cbtNum">{{data.result.cbt[0].dlNo.slice(3,4)}}</div>
            <span class="numTip">笔</span>
          </div>
        </div>
        <div class="hot-trading-info fir-hot-info" v-else>
					<div class="bondNm2"> </div>
					<div class="dealNum">
            <div class="num cbtNum">0</div>
            <div class="num cbtNum">0</div>
            <div class="num cbtNum">0</div> 
            <div class="num cbtNum">0</div>
            <span class="numTip">笔</span>
          </div>
        </div>
				<div class="hot-trading-info sec-hot-info" v-if="data.result.cbt[1]">
				  <div class="bondNm">{{data.result.cbt[1].show}}</div>
					<div class="dealNum">
            <div class="num cbtNum">{{data.result.cbt[1].dlNo.slice(0,1)}}</div>
            <div class="num cbtNum">{{data.result.cbt[1].dlNo.slice(1,2)}}</div>
            <div class="num cbtNum">{{data.result.cbt[1].dlNo.slice(2,3)}}</div> 
            <div class="num cbtNum">{{data.result.cbt[1].dlNo.slice(3,4)}}</div>
            <span class="numTip">笔</span>
          </div>
        </div>
        <div class="hot-trading-info sec-hot-info" v-else>
					<div class="bondNm2"> </div>
					<div class="dealNum">
            <div class="num cbtNum">0</div>
            <div class="num cbtNum">0</div>
            <div class="num cbtNum">0</div> 
            <div class="num cbtNum">0</div>
            <span class="numTip">笔</span>
          </div>
        </div>
        <div class="hot-trading-info third-hot-info" v-if="data.result.cbt[2]">
          <div class="bondNm">{{data.result.cbt[2].show}}</div>
          <div class="dealNum">
            <div class="num cbtNum">{{data.result.cbt[2].dlNo.slice(0,1)}}</div>
            <div class="num cbtNum">{{data.result.cbt[2].dlNo.slice(1,2)}}</div>
            <div class="num cbtNum">{{data.result.cbt[2].dlNo.slice(2,3)}}</div> 
            <div class="num cbtNum">{{data.result.cbt[2].dlNo.slice(3,4)}}</div>
            <span class="numTip">笔</span>
          </div>
        </div>
        <div class="hot-trading-info third-hot-info" v-else>
					<div class="bondNm2"> </div>
					<div class="dealNum">
            <div class="num cbtNum">0</div>
            <div class="num cbtNum">0</div>
            <div class="num cbtNum">0</div> 
            <div class="num cbtNum">0</div>
            <span class="numTip">笔</span>
          </div>
        </div>
			</div>
		</div>
    <div class="irsCon">
      <div class="hot-trading-title">
        利率互换
      </div>
      <div class="clear">
				<div class="hot-trading-info fir-hot-info" v-if="data.result.irs[0]">
					<div class="bondNm">{{data.result.irs[0].show}}</div>
					<div class="dealNum">
            <div class="num irsNum">{{data.result.irs[0].dlNo.slice(0,1)}}</div>
            <div class="num irsNum">{{data.result.irs[0].dlNo.slice(1,2)}}</div>
            <div class="num irsNum">{{data.result.irs[0].dlNo.slice(2,3)}}</div> 
            <div class="num irsNum">{{data.result.irs[0].dlNo.slice(3,4)}}</div>
            <span class="numTip">笔</span>
          </div>
        </div>
        <div class="hot-trading-info fir-hot-info" v-else>
					<div class="bondNm2"></div>
					<div class="dealNum">
            <div class="num irsNum">0</div>
            <div class="num irsNum">0</div>
            <div class="num irsNum">0</div> 
            <div class="num irsNum">0</div>
            <span class="numTip">笔</span>
          </div>
        </div>
				<div class="hot-trading-info sec-hot-info" v-if="data.result.irs[1]">
				  <div class="bondNm">{{data.result.irs[1].show}}</div>
					<div class="dealNum">
            <div class="num irsNum">{{data.result.irs[1].dlNo.slice(0,1)}}</div>
            <div class="num irsNum">{{data.result.irs[1].dlNo.slice(1,2)}}</div>
            <div class="num irsNum">{{data.result.irs[1].dlNo.slice(2,3)}}</div> 
            <div class="num irsNum">{{data.result.irs[1].dlNo.slice(3,4)}}</div>
            <span class="numTip">笔</span>
          </div>
        </div>
        <div class="hot-trading-info sec-hot-info" v-else>
					<div class="bondNm2"></div>
					<div class="dealNum">
            <div class="num irsNum  ">0</div>
            <div class="num irsNum  ">0</div>
            <div class="num irsNum  ">0</div> 
            <div class="num irsNum  ">0</div>
            <span class="numTip">笔</span>
          </div>
        </div>
        <div class="hot-trading-info third-hot-info" v-if="data.result.irs[2]">
          <div class="bondNm">{{data.result.irs[2].show}}</div>
          <div class="dealNum">
            <div class="num irsNum">{{data.result.irs[2].dlNo.slice(0,1)}}</div>
            <div class="num irsNum">{{data.result.irs[2].dlNo.slice(1,2)}}</div>
            <div class="num irsNum">{{data.result.irs[2].dlNo.slice(2,3)}}</div> 
            <div class="num irsNum">{{data.result.irs[2].dlNo.slice(3,4)}}</div>
            <span class="numTip">笔</span>
          </div>
        </div>
        <div class="hot-trading-info third-hot-info" v-else>
					<div class="bondNm2"><div style="display:none;"></div></div>
					<div class="dealNum">
            <div class="num irsNum  ">0</div>
            <div class="num irsNum  ">0</div>
            <div class="num irsNum  ">0</div> 
            <div class="num irsNum  ">0</div>
            <span class="numTip">笔</span>
          </div>
        </div>
			</div>
    </div>
  </div>
</template>

<script lang="ts">
import { createNamespacedHelpers } from 'vuex'

const { mapState, mapActions } = createNamespacedHelpers('hotTrading')
export default {
  name: 'hotTrading',
  data: function () {
    return {
      interval: 0
    }
  },
  created: function () {
    this.interval = setInterval(() => {
      this.getHotTrading()
    }, 1000)
  },
  methods: {
    // 在 `hotTrading 数据模块` 中查找并绑定方法
    ...mapActions(['addCount', 'getHotTrading'])
  },
  computed: {
    ...mapState({
      count: state => state.count,
      hotTradingList: state => state.hotTradingList,
      data: state => state.data
    })
  },
  beforeDestroy: function () {
    if (this.interval) {
      clearInterval(this.interval)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
.hot-trading-title {
  color: @color_9fd2e3;
  font-family: '微软雅黑';
  font-size: 1.25rem;
  height: 1.25rem;
  line-height: 1.25rem;
  // margin-top: 6.2%;
  margin-bottom: 7.4%;
}
.con {
  margin-top: 3.5%;
  background-size: 100%;
  width: 100%;
  height: 33.3%;
  padding-top: 8.5%;
}
.hotCon {
  height: 100%;
}
.crpoCon {
  background: url('../assets/bang4.png') no-repeat center center;
  .con;
  margin-top: 0%;
}
.cbtCon {
  background: url('../assets/bang4.png') no-repeat center center;
 .con;
}
.irsCon {
  background: url('../assets/bang4.png') no-repeat center center;
 .con;
}


.hot-trading-info {
  color: @color_fff;
  float: left;
  text-align: center;
  margin-left: 2%;
  margin-right: 2%;
}
.fir-hot-info {
  // width: 34.6%;
  margin-left: 6.1%;
  margin-right: 2%;
}
.sec-hot-info {
  // width: 23%;
}
.third-hot-info {
  // width: 23%;
}
.bondNm {
	color: @color_9fd2e3;
  font-size: 0.875rem;
  padding-top: 0.3125rem;
  padding-bottom: 0.3125rem;
  border: 1px transparent solid;
  border-image: linear-gradient(to right, #183751,#0096a8,#183751) 1 10;
  border-left: none;
  border-right: none;
  font-family: '微软雅黑'
}
.bondNm2 {
  height: 1.92rem;
  border: 1px transparent solid;
  border-image: linear-gradient(to right, #183751,#0096a8,#183751) 1 10;  
  border-left: none;
  border-right: none;
}
.dealNum {
  background: url('../assets/bang1.png') no-repeat center center;
  background-size: 100%;
	color: @color_fff;
	font-size: 1.5625rem;
  margin-top: 1.3125rem;
  text-align: left;
  padding: 0.625rem;
  .num {
    display: inline-block;
    width: 1.25rem;
    height: 3.2%;
    margin-left: 1px;
    margin-right: 1px;    
    font-weight: bolder;
    font-size: 1.5rem;
    text-align: center;
  }
  .crpoNum {
    background: linear-gradient(#0096a8,#27f8fc);
  }
  .cbtNum {    
    background: linear-gradient(#ac7603,#f5cc6c);
  }
  .irsNum {
    background: linear-gradient(#723ab3,#9b47fd);
  }
  .numTip {
    color: @color_9fd2e3;
    font-size: 0.75rem;
    margin-left: 0.1875rem;
  }
}
@color_9fd2e3: #9fd2e3;
@color_fffffd: #fffffd;
@color_fff: #fff;
</style>