<template>
  <div class="time">
    {{data}}
  </div>
</template>

<script lang="ts">
import { createNamespacedHelpers } from 'vuex'

const { mapState, mapActions } = createNamespacedHelpers('currentTime')
export default {
  name: 'currentTime',
  data: function () {
    return {
      interval: 0
    }
  },
  created: function () {
    this.interval = setInterval(() => {
      this.getCurrentTime()
    }, 1000)
  },
  methods: {
    // 在 `hotTrading 数据模块` 中查找并绑定方法
    ...mapActions(['getCurrentTime'])
  },
  computed: {
    ...mapState({
      data: state => state.data
    })
  },
  beforeDestroy: function () {
    if (this.interval) {
      clearInterval(this.interval)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
.time {
  color: #fff;
  font-family: Arial, Black;
  font-size: 1.875rem;
  font-weight: bold;
  position: absolute;
  bottom: 4%;
  right: 15%;
  letter-spacing: 0.2rem;
}
</style>
