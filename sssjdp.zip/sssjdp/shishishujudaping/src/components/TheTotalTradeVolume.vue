<template>
  <div class="total-volume">
    <div class="volCon">
      <i class="moneyIcon"></i>
      <span class="totalNum">{{data.volAll?data.volAll:'0'}}</span>
    </div>
    <div class="volNum">
        <span class="arial">{{data.dealNoAll?data.dealNoAll:'0'}}</span>
        <span class="totalTip">笔成交</span>
        <span class="peek">成交峰值:
        <span class="arial">{{data.time?data.time:'00:00:00'}}</span>&nbsp;&nbsp;
        <span class="arial">{{data.peak?data.peak:'0'}}</span>笔/秒</span>
    </div>
  </div>
</template>

<script lang="ts">
import { createNamespacedHelpers } from 'vuex'

const { mapState, mapActions } = createNamespacedHelpers('theTotalTradeVolume')
export default {
  name: 'theTotalTradeVolume',
  data: function () {
    return {
      interval: 0
    }
  },
  methods: {
  },
  computed: {
    ...mapState({
      count: state => state.count,
      hotTradingList: state => state.hotTradingList,
      data: state => state.data
    })
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
  .total-volume {
      height: 28%;
      font-family: '微软雅黑';
      width:120%;
      position:relative;
      left:-3.3rem;
      }
      .volCon {
      padding-top: 20%;
      }
    .moneyIcon {
        background: url('../assets/money.png') no-repeat center center;
        width: 4.375rem;
        height: 5rem;
        display: inline-block;
        background-size: 100%;
        vertical-align: middle;
    }
    .totalNum {
        color: #ffed98;
        font-family: Arial;
        font-weight: bold;
        font-size: 4.125rem;
        vertical-align: middle;
    }
    .volNum {
        color: #fff;
        font-size: 1.875rem;
        .arial {
          font-family: Arial;
          vertical-align: bottom;
        }
        .peek{
          font-size: 1rem;
          margin-left: 1rem;
          vertical-align: bottom;
        }
    }
</style>