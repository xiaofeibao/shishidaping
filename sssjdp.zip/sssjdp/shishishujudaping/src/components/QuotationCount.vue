<template>
  <div class="login-info">
      <!-- 20家机构报价笔数柱状图 -->
      <div
        :id="id"
        class="pieChart"
        :style="{height: height, width: width}"
      />
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator'

@Component
export default class QuotationCount extends Vue {
  // @Prop({ default: 'chart' }) private className!: string
  @Prop({ default: 'chart' }) private id!: string
  @Prop({ default: '12.5rem' }) private width!: string
  @Prop({ default: '12.5rem' }) private height!: string
  public $echarts: any; // 柱状图
  private options: object = { // 柱状图
    dataset: {
      source: [
        ['score', 'amount', 'product'],
        [89.3, 58212, 'Matcha Latte'],
        [57.1, 78254, 'Milk Tea'],
        [74.4, 41032, 'Cheese Cocoa'],
        [50.1, 12755, 'Cheese Brownie'],
        [89.7, 20145, 'Matcha Cocoa'],
        [68.1, 79146, 'Tea'],
        [19.6, 91852, 'Orange Juice'],
        [10.6, 101852, 'Lemon Juice'],
        [32.7, 20112, 'Walnut Brownie']
      ]
    },
    grid: { containLabel: true },
    xAxis: { name: 'amount' },
    yAxis: { type: 'category' },
    visualMap: {
      orient: 'horizontal',
      left: 'center',
      min: 10,
      max: 100,
      text: ['High Score', 'Low Score'],
      // Map the score column to color
      dimension: 0,
      inRange: {
        color: ['#D7DA8B', '#E15457']
      }
    },
    series: [
      {
        type: 'bar',
        encode: {
          // Map the "amount" column to X axis.
          x: 'amount',
          // Map the "product" column to Y axis
          y: 'product'
        }
      }
    ]
  }

  private initChart () {
    const ele = document.getElementById(this.id)
    const chart: any = this.$echarts.init(ele)
    if (this.options && typeof this.options === 'object') {
      chart.setOption(this.options, true)
    }
  }

  private mounted () {
    this.$nextTick(() => {
      this.initChart()
    })
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
    .login-info {
        border: 1px solid red;
    }
    .pieChart {
        position: absolute;
        left: 25rem;
        top: 3.125rem;
    }
</style>
