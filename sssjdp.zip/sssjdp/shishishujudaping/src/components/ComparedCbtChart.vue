<template>
  <div>
      <!-- 现券买卖柱状图 -->
      <div id="comparedCbtChartId" />
  </div>
</template>

<script lang="ts">
import { createNamespacedHelpers } from 'vuex'

const { mapState } = createNamespacedHelpers('comparedCbtChart')
export default {
  name: 'comparedCbtChart',
  data: function () {
    return {
      interval: 0
    }
  },
  chart: null,
  methods: {
    // 在 `hotTrading 数据模块` 中查找并绑定方法
    initChart () {
      let dataAxis = this.data.instiNmList
      let data = this.data.instiNumList
      let voldata = this.data.instiVolList
      let yMax = 300
      let dataShadow = []
      let zoomSize = 1
      let options= { // 柱状图
        tooltip: { // 柱子遮罩提示
          trigger: 'axis',
          axisPointer: {            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
          }
        },
        grid: {  //图表margin
            left: '10%',
            right: '8%',
            bottom: '18%',
            top: '8%',
            containLabel: true
        },
        title: {
          // text: '特性示例：渐变色 阴影 点击缩放',
          // subtext: 'Feature Sample: Gradient Color, Shadow, Click Zoom'
        },
        xAxis: {
          data: dataAxis,
          axisLabel: {
            inside: false, //true ：横坐标字在柱子上
            textStyle: {
              color: '#9fd2e3', //横坐标文字颜色
              fontSize: '100%'
            },
            formatter(value,index) {
              if(value.length>4) {
                return value.substr(0,4)+"\n"+value.substr(4,4)+"\n"+value.substr(8)
              }else {
                return value
              }
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {//坐标
            show: true
          },
          z: 10
        },
        yAxis: { 
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            textStyle: {
              color: '#9fd2e3',
              fontSize: '100%'
            }
          },
          splitLine: {//标线
            show: false
          },
        },
        dataZoom: [
          {
            type: 'inside'
          }
        ],
        series: [
          // { // For shadow
          //   type: 'bar',
          //   itemStyle: {
          //     color: 'rgba(0,0,0,0)'// 设置柱子背景阴影
          //   },
          //   barGap: '-100%',
          //   barCategoryGap: '40%',
          //   data: dataShadow,
          //   animation: false
          // },
          {
            type: 'bar',
            itemStyle: {
              color: new this.$echarts.graphic.LinearGradient(
                0, 0, 0, 1,
                [
                  { offset: 0, color: '#f5cb69' },//柱顶
                  { offset: 0.2, color: '#d1b161' },
                  { offset: 0.5, color: '#806f50' },
                  { offset: 1, color: '#483f3f' }// 柱底
                ]
              )
            },
            barMaxWidth: 20,
            emphasis: {
              itemStyle: {
                color: new this.$echarts.graphic.LinearGradient(
                  0, 0, 0, 1,
                  [
                    { offset: 0, color: '#f5cb69' },
                    { offset: 0.7, color: '#806f50' },
                    { offset: 1, color: '#483f3f' }
                  ]
                )
              }
            },
            data: data
          },
          {
            type: 'bar',
            itemStyle: {
              color: new this.$echarts.graphic.LinearGradient(
                0, 0, 0, 1,
                [
                  { offset: 0.1, color: '#ef4858' },//柱顶
                  { offset: 0.4, color: '#a7313c' },
                  { offset: 0.6, color: '#863139' },
                  { offset: 0.9, color: '#6f2025' }// 柱底
                ]
              )
            },
            barMaxWidth: 20,
            emphasis: {
              itemStyle: {
                color: new this.$echarts.graphic.LinearGradient(
                  0, 0, 0, 1,
                  [
                    { offset: 0, color: '#f13f51' },
                    { offset: 0.5, color: '#b7303d' },
                    { offset: 1, color: '#8c3038' }
                  ]
                )
              }
            },
            data: voldata
          },
        ]
      }
      if(data && data.length>0){
        for (let i = 0; i < data.length; i++) {
          dataShadow.push(yMax)
        }
      }
      const ele = document.getElementById('comparedCbtChartId')
      if(!this.chart) {
        this.chart = this.$echarts.init(ele)
      }
      if (options && typeof options === 'object') {
        this.chart.setOption(options, true)
      }
    }
  },
  computed: {
    ...mapState({
      count: state => state.count,
      loginList: state => state.loginList,
      data: state => state.data
    })
  },
  watch: {
    data(e) {
      this.initChart();
    }
  },
  beforeDestroy: function () {
    if (this.interval) {
      clearInterval(this.interval)
    }
  }
  // @Prop({ default: 'chart' }) private className!: string
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  #comparedCbtChartId {
    height: 100%;
    width: 100%;
    position: relative;
    bottom:0px;
    font-size: 0.7rem;
  }
</style>
