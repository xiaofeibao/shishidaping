<template>
  <div class='login-info'>
    <div>{{count}}</div>
    <div>{{data.time.updated}}</div>
    <!--20家机构登录情况轮播-->
    <div id='scrollBox'>
      <ul id='con1'>
          <!-- <li v-for='item in instiList' v-bind:key='item.index'>{{item}}</li> -->
      </ul>
      <ul id='con2'></ul>
    </div>
  </div>
</template>

<script lang='ts'>
import { createNamespacedHelpers } from 'vuex'
// 引入数据模块的命名空间
const { mapState, mapActions } = createNamespacedHelpers('loginInfo')

export default {
  name: 'LoginInfo',
  data: function () {
    return {
      interval: 0
    }
  },
  created: function () {
    // this.interval = setInterval (() => {
      this.getData();
    // }, 1000)
    // this.lunbo();
  },
  methods: {
    // 在 `loginInfo 数据模块` 中查找并绑定方法
    ...mapActions(['addCount', 'getData'])
  },
  computed: {
    ...mapState({
      count: state => state.count,
      loginList: state => state.loginList,
      data: state => state.data
    })
  },
  beforeDestroy: function () {
    if (this.interval) {
      clearInterval(this.interval);
    }
  },
  // 轮播动态效果
  // lunbo () {
  //   const area = document.getElementById('scrollBox')
  //   const con1 = document.getElementById('con1')
  //   const con2 = document.getElementById('con2')
  //   const time = 40
  //   if (area) {
  //     let mytimer = setInterval(function () {
  //       if (area.scrollTop >= con1.offsetHeight) {
  //         area.scrollTop = 0
  //       } else {
  //         area.scrollTop++
  //       }
  //     }, time)
  //     con2.innerHTML = con1.innerHTML

  //     area.onmousemove = (e) => {
  //       clearInterval(mytimer)
  //     }

  //     area.onmouseout = (e) => {
  //       mytimer = setInterval(function () {
  //         if (area.scrollTop >= con1.offsetHeight) {
  //           area.scrollTop = 0
  //         } else {
  //           area.scrollTop++
  //         }
  //       }, time)
  //     }
  //   }
  // }
}
</script>

<!-- Add 'scoped' attribute to limit CSS to this component only -->
<style scoped>
ul,
li {
  list-style: none;
  display: block;
}
/* .login-info {
        border: 1px solid red;
    } */
* {
  margin: 0;
  padding: 0;
}
#scrollBox {
  height: 10.625rem;
  width: 18.75rem;
  overflow: hidden;
  background: #eee;
  float: left;
}
#scrollBox #con1,
#con2 {
  width: 17.5rem;
  float: left;
}
#scrollBox li {
  height: 1.5625rem;
  line-height: 1.5625rem;
  text-align: center;
}
</style>