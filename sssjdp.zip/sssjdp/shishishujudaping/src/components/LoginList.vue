<template>
  <div>
    <!-- 用户登录类型饼图（专线，互联网，api） -->
    <div class="loginNum">
      <div v-if="loginInfo && loginInfo[1]">
        专线网登录机构
        <span class="num">{{loginInfo[1].instn?loginInfo[1].instn:'0'}}</span> 家
        <span class="num">{{loginInfo[1].user?loginInfo[1].user:'0'}}</span> 用户
      </div>
      <div>
        API登录机构
        <span class="num">{{loginInfo[2].instn?loginInfo[2].instn:'0'}}</span> 家
        <span class="num">{{loginInfo[2].user?loginInfo[2].user:'0'}}</span> 用户
      </div>
      <div>
        互联网登录机构
        <span class="num">{{loginInfo[0].instn?loginInfo[0].instn:'0'}}</span> 家
        <span class="num">{{loginInfo[0].user?loginInfo[0].user:'0'}}</span> 用户
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";
import { createNamespacedHelpers } from "vuex";
import Axios from "axios";

const { mapState, mapActions } = createNamespacedHelpers("LoginList");

@Component
export default class LoginList extends Vue {
  //   @Prop({ default: 'chart' }) private className!: string
  @Prop({ default: "chart" }) private id!: string;
  @Prop({ default: "12.5rem" }) private width!: string;
  @Prop({ default: "12.5rem" }) private height!: string;
  private chart: any;
  public srcMap = {
    "0": "互联网",
    "1": "专线网",
    "2": "API"
  };
  public loginInfo = [];
  public pieData = [];
  public $echarts: any; // 饼图
  private interval = 0;
  private inSearch = false;
  private options: object = {
    tooltip: {
      trigger: "item",
      formatter: "{a} <br/>{b} : {c} ({d}%)"
    },
    series: []
  };
  private created() {
    this.getLoginData();
    this.interval = setInterval(() => {
      if(this.inSearch == false) {
        this.getLoginData();
      }
    }, 1000)
  }

  private getLoginData() {
    this.inSearch = true;
    Axios.post(
      "/tbs/hawk/rest/tbs-ur-hawk/loginPieData"
    )
      .then(response => response.data.data)
      .then(data => {
        this.loginInfo = data.result;
        this.inSearch = false;
      })
      .catch(() => {
        this.inSearch = false;
      });
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
.login-list-title {
  color: #fff;
  font-family: "微软雅黑";
}
.login-list {
  background-size: 100% 100%;
  width: 100%;
  height: 100%;
}
.login-list-title {
  color: #fff;
  font-family: "微软雅黑";
}
.loginNum {
  position: absolute;
  line-height: 1.8rem;
  z-index: 500;
  left: 15%;
  text-align: left;
  top: 12%;
  font-size: 0.85rem;
}
.num {
  font-size: 1.4rem;
  color: #fff;
}
.textOverflow {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.chartColorTip {
  width: 80%;
  position: absolute;
  left: 15%;
  bottom: 10%;
  text-align: left;
}
.mb {
  bottom: 6%;
}
.firstLine {
  bottom: 14%;
}
.market {
  width: 1rem;
  height: 0.625rem;
  display: inline-block;
  vertical-align: middle;
}
.crpoT,
.cbtT,
.irsT,
.sirsT,
.sbfT {
  float: left;
  width: 33.3%;
  .textOverflow;
}
.marketNm {
  font-size: 0.7rem;
  margin-left: 0.3rem;
}
</style>
