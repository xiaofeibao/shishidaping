<template>
  <!-- 核心交易商报价笔数 -->
  <div>
        <div
          id="dealListChartId"
        >
      </div>
  </div>
</template>

<script lang="ts">
import { createNamespacedHelpers } from 'vuex'

const { mapState, mapActions } = createNamespacedHelpers('dealListChart')

export default {
  name: 'DealListChart',
  data: function () {
    return {
      interval: 0,
      chart: null
    }
  },
  created: function () {
    this.getDealListChart()
    this.interval = setInterval(() => {
      this.getDealListChart()
    }, 1000)
  },
  methods: {
    // 在 `hotTrading 数据模块` 中查找并绑定方法
    ...mapActions(['getDealListChart']),
    initChart () {
      let yMax = 300
      let zoomSize = 1
      let options: object = { // 柱状图
   
        grid: { 
          containLabel: true,
          left:'15%'
        },
        xAxis: { 
          name: '',
          axisLabel: {
            inside: false, //true ：横坐标字在柱子上
            textStyle: {
              color: '#9fd2e3', //横坐标文字颜色
              fontSize:'100%'
            },
          },
          axisTick: {
            show: false
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: false
          },
          z: 10,
          minInterval: 1
        },
        yAxis: { 
          type: 'category',
          splitNumber:20,
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            textStyle: {
              color: '#9fd2e3',
              fontSize:'100%'
            },
          }
        },
        legend: {
          data: ['质押式回购','现券买卖','利率互换'],
          top: 25,
          left: 'center',
          itemWidth: 15,
          itemHeight: 10,
          borderRadius: 0,
          textStyle: {
            color: '#9fd2e3',
          },
          fontSize: '100%'
        },
        // series: [
          
        // ]
      }
      const ele = document.getElementById('dealListChartId')
      this.chart = this.$echarts.init(ele)
      if (options && typeof options === 'object') {
        this.chart.setOption(options, true)
        this.$forceUpdate();
      }
    }
  },
  computed: {
    ...mapState({
      crList: (state: any) => state.crList,
      cbtList: (state: any) => state.cbtList,
      irsList: (state: any) => state.irsList
    }),
  },
  watch: {
    crList(){
      this.chart.setOption({
        series: [
          {
            type: 'bar',
            name: '质押式回购',
            stack: 'one',
            itemStyle: {
              color: '#27f8fc'
            },
            data: this.crList
          },
          {
            type: 'bar',
            stack: 'one',
            name: '现券买卖',
            itemStyle: {
              color: '#f5cc6c'
            },
            data: this.cbtList
          },
          {
            type: 'bar',
            stack: 'one',
            name: '利率互换',
            itemStyle: {
              color: '#9b47fd'
            },
            data: this.irsList
          }
        ]
      });
    }
    // seriesOption(val){
    //   console.log(val);
    //   this.setOption({
    //     series: val
    //   });
    // }
  },
  mounted: function() {
    this.$nextTick(() => {
      this.initChart()
    })
  },
  beforeDestroy: function () {
    if (this.interval) {
      clearInterval(this.interval)
    }
  }
  // @Prop({ default: 'chart' }) private className!: string
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .deal-list {
    background: url('../assets/beforeLogin.png') no-repeat center;
    background-size: 100% 100%;
    width: 100%;
    height: 100%;
  }
</style>