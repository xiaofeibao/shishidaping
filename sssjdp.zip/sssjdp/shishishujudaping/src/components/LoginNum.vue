<!--
 * @Author: your name
 * @Date: 2020-04-07 13:28:07
 * @LastEditTime: 2020-04-07 14:49:57
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \screen\src\components\LoginNum.vue
 -->
<template>
  <div class="login-info">
    互联网登陆情况
  </div>
</template>

<script lang="ts">
import { createNamespacedHelpers } from 'vuex'

const { mapState, mapActions } = createNamespacedHelpers('loginNum')
export default {
  name: 'loginNum',
  data: function () {
    return {
      interval: 0
    }
  },
  created: function () {
    // this.interval = setInterval(() => {
      this.getLoginNum()
    // }, 1000)
  },
  methods: {
    // 在 `loginNum 数据模块` 中查找并绑定方法
    ...mapActions(['addCount', 'getLoginNum'])
  },
  computed: {
    ...mapState({
      count: state => state.count,
      data: state => state.data
    })
  },
  beforeDestroy: function () {
    if (this.interval) {
      clearInterval(this.interval)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .login-info {
      border: 1px solid red;
  }
</style>
