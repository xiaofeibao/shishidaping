<template>
  <div>
    <!-- 用户登录类型饼图（专线，互联网，api） -->
    <div class="login-list-title">登录机构总览</div>
    <div class="loginNum" v-if="loginInfo">
      <div v-for="item in loginInfo" :key="item.datasrc">
        {{item.instiNm?item.instiNm:''}}登录机构
        <span class="num">{{item.instn?item.instn:'0'}}</span> 家
        <span class="num">{{item.user?item.user:'0'}}</span> 用户
      </div>

    </div>
    <div class="login-list">
      <div class="userTypeBorderOut">

        
        <div class="userTypeBorderInner">
          <div :id="id" :style="{height: height, width: width,margin: '-0.5rem 0 0 -0.4375rem'}"/>
        </div>
      </div>
      <div class="chartColorTip firstLine">
        <div class="crpoT">
          <span class="market crpoM"></span>
          <span class="marketNm">资管类</span>
        </div>
        <div class="cbtT">
          <span class="market cbtM"></span>
          <span class="marketNm">商业银行</span>
        </div>
        <div class="irsT">
          <span class="market irsM"></span>
          <span class="marketNm">政策性银行</span>
        </div>
      </div>
      <div class="chartColorTip">
        <div class="sirsT">
          <span class="market sirsM"></span>
          <span class="marketNm">农村金融机构</span>
        </div>
        <div class="sbfT">
          <span class="market sbfM"></span>
          <span class="marketNm">证券公司</span>
        </div>
        <div class="sbfT">
          <span class="market sixM"></span>
          <span class="marketNm">其他非银</span>
        </div>
      </div>
      <div class="chartColorTip mb">
        <div class="sirsT">
          <span class="market jwjg"></span>
          <span class="marketNm">境外机构</span>
        </div>
        <div class="sbfT">
          <span class="market other"></span>
          <span class="marketNm">其他</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";
import { createNamespacedHelpers } from "vuex";
import Axios from "axios";

const { mapState, mapActions } = createNamespacedHelpers("userTypeChart");

@Component
export default class UserTypeChart extends Vue {
  //   @Prop({ default: 'chart' }) private className!: string
  @Prop({ default: "chart" }) private id!: string;
  @Prop({ default: "17rem" }) private width!: string;
  @Prop({ default: "17rem" }) private height!: string;
  private chart: any;
  private inSearch = false;
  public srcMap = [
    {
      no:'1',
      instiNm: '专线网'
    },
    {
      no:'2',
      instiNm: 'API'
    },
    {
      no:'0',
      instiNm: '互联网'
    }
  ];
  public loginInfo = [];
  public pieData = [];
  public $echarts: any; // 饼图
  private interval = 0;
  private options: object = {
    tooltip: {
      trigger: "item",
      formatter: "{a} <br/>{b} : {c} ({d}%)"
    },
    // legend: {
    //   data: ['资管类','商业银行','政策性银行','农村金融机构','证券公司','其他非银','境外机构','其他'],
    //   top: 160,
    //   left: 'center',
    //   itemWidth: 15,
    //   itemHeight: 10,
    //   borderRadius: 0,
    //   textStyle: {
    //     color: '#9fd2e3',
    //     fontSize: 12
    //   }
    // },
    series: []
  };

  private initChart() {
    const ele = document.getElementById(this.id);
    this.chart = this.$echarts.init(ele);
    if (this.options && typeof this.options === "object") {
      this.chart.setOption(this.options, true);
    }
  }

  private mounted() {
    this.$nextTick(() => {
      this.initChart();
    });
  }

  private created() {
    this.getLoginData();
    this.getLoginPieData();
    this.interval = setInterval(() => {
      if(this.inSearch == false) {
        this.getLoginData();
        this.getLoginPieData();
      }
    }, 1000)
  }

  private getLoginData() {
    this.inSearch = false;
    Axios.post(
      "/tbs/hawk/rest/tbs-ur-hawk/loginPieData"
    )
      .then(response => response.data.data)
      .then(data => {
        this.inSearch = false;
        this.srcMap.forEach( (item:any) => {
          data.result.forEach( (subItem:any) => {
            if(item.no == subItem.datasrc) {
              item.instn = subItem.instn;
              item.user = subItem.user;
            }
          });
        })
        this.loginInfo = JSON.parse(JSON.stringify(this.srcMap));
        // this.$forceUpdate();
        // this.loginInfo = [
        //   {
        //     datasrc: "0",
        //     instn: 48,
        //     user: 120
        //   },
        //   {
        //     datasrc: "1",
        //     instn: 3579,
        //     user: 6455
        //   },
        //   {
        //     datasrc: "2",
        //     instn: 23,
        //     user: 125
        //   }
        // ];
      }).catch(() => {
        this.inSearch = false;
      });
  }

  private getLoginPieData() {
    Axios.post(
      "/tbs/hawk/rest/tbs-ur-hawk/instnTpData"
    )
      .then(response => response.data.data)
      .then(data => {
        const result = data.result;
        const styleMap = [
          { name: "资管类", itemStyle: { color: "#27f8fc" } },
          { name: "商业银行", itemStyle: { color: "#f5cc6c" } },
          { name: "政策性银行", itemStyle: { color: "#9b47fd" } },
          { name: "农村金融机构", itemStyle: { color: "#f86271" } },
          { name: "证券公司", itemStyle: { color: "#5277ff" } },
          { name: "其他非银", itemStyle: { color: "#48ff96" } },
          { name: "境外机构", itemStyle: { color: "#fdff4a" } },
          { name: "其他", itemStyle: { color: "#e0e0e0" } }
        ];
        this.pieData = result.map((e: any) => {
          const itemStyle = styleMap.find((ee: any) => ee.name == e.instnTp)
            .itemStyle;
          return {
            value: e.size,
            name: e.instnTp,
            itemStyle
          };
        });
        this.chart.setOption({
          series: [
            {
              name: "访问来源",
              type: "pie",
              radius: "75%",
              center: ["50%", "50%"],
              data: this.pieData.sort(function(a, b) {
                return a.value - b.value;
              }),
              roseType: "radius",
              // label: {
              //     color: 'rgba(255, 255, 255, 0.3)'
              // },
              label: {
                show: false
              },
              // labelLine: {
              //     lineStyle: {
              //         color: 'rgba(255, 255, 255, 0.3)'
              //     },
              //     smooth: 0.2,
              //     length: 10,
              //     length2: 20
              // },
              labelLine: {
                show: false
              },
              itemStyle: {
                color: "#c23531",
                shadowBlur: 200,
                shadowColor: "rgba(0, 0, 0, 0.5)"
              },
              animationType: "scale",
              animationEasing: "elasticOut",
              animationDelay: function(idx) {
                return Math.random() * 200;
              }
            }
          ]
        });
      });
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
/* .login-info {
      border: 1px solid red;
  } */
.pieChart {
}
.login-list-title {
  color: #fff;
  font-family: "微软雅黑";
}
.login-list {
  background: url("../assets/beforeLogin.png") no-repeat center;
  background-size: 100% 100%;
  width: 100%;
  height: 100%;
}
.userTypeBorderOut {
  margin-left: calc(50% - 5.625rem);
  width: 12.5rem;
  height: 12.5rem;
  border: 1px solid #2061cc;
  border-radius: 6.25rem;
  top: 32%;
  position: relative;
}
.userTypeBorderInner {
  margin-left: calc(50% - 8.5rem);
  width: 17rem;
  height: 17rem;
  border: 1px solid #2061cc;
  border-radius: 8.5rem;
  margin-top: 0.5rem;
}
.login-list-title {
  color: #fff;
  font-family: "微软雅黑";
  font-size: 1.875rem;
}
.loginNum {
  position: absolute;
  line-height: 1.5rem;
  z-index: 500;
  left: 15%;
  text-align: left;
  top: 12%;
}
.num {
  font-size: 1.8rem;
  color: #fff;
}
.textOverflow {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.chartColorTip {
  width: 80%;
  position: absolute;
  left: 15%;
  bottom: 10%;
  text-align: left;
}
.mb {
  bottom: 6%;
}
.firstLine {
  bottom: 14%;
}
.market {
  width: 1rem;
  height: 0.625rem;
  display: inline-block;
  vertical-align: middle;
}
.crpoT,
.cbtT,
.irsT,
.sirsT,
.sbfT {
  float: left;
  width: 33.3%;
  .textOverflow;
}
.crpoM {
  .market;
  background-color: #27f8fc;
}
.cbtM {
  .market;
  background-color: #f5cc6c;
}
.irsM {
  .market;
  background-color: #9b47fd;
}
.sirsM {
  .market;
  background-color: #f86271;
}
.sbfM {
  .market;
  background-color: #5277ff;
}
.sixM {
  .market;
  background-color: #48ff96;
}
.jwjg {
  .market;
  background-color: #fdff4a;
}
.other {
  .market;
  background-color: #e0e0e0;
}
.marketNm {
  font-size: 0.9rem;
  margin-left: 0.3rem;
}
</style>