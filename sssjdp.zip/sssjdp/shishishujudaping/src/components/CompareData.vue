<template>
  <div class="compare">
    <div class="crpoCon" v-if="data.crpoData">
      <div class="conTitle">质押式回购</div>
      <div class="data">共成交<span class="fColor">{{data.crpoData.dealNo?data.crpoData.dealNo:'0'}}</span>&nbsp;&nbsp;笔</div>
      <div class="data">交易金额<span class="fColor">{{data.crpoData.vol/10000}}</span>亿元</div>
      <div class="data" v-if="data.crpoData.sameCompare && data.crpoData.sameCompare.indexOf('-')==-1">同比增长<span class="fColor">{{data.crpoData.sameCompare}}</span></div>
      <div class="data" v-if="data.crpoData.linkRelative && data.crpoData.linkRelative.indexOf('-')==-1">环比增长<span class="fColor">{{data.crpoData.linkRelative}}</span></div>
    </div>
    <div class="cbtCon" v-if="data.cbtData">
      <div class="conTitle">现券买卖</div>
      <div class="data">共成交<span class="fColor">{{data.cbtData.dealNo?data.cbtData.dealNo:'0'}}</span>&nbsp;&nbsp;笔</div>
      <div class="data">交易金额<span class="fColor">{{data.cbtData.vol/10000}}</span>亿元</div>
      <div class="data" v-if="data.cbtData.sameCompare && data.cbtData.sameCompare.indexOf('-')==-1">同比增长<span class="fColor">{{data.cbtData.sameCompare}}</span></div>
      <div class="data" v-if="data.cbtData.linkRelative && data.cbtData.linkRelative.indexOf('-')==-1">环比增长<span class="fColor">{{data.cbtData.linkRelative}}</span></div>
    </div>
    <div class="irsCon" v-if="data.irsData">
      <div class="conTitle">利率互换</div>
      <div class="data">共成交<span class="fColor">{{data.irsData.dealNo?data.irsData.dealNo:'0'}}</span>&nbsp;&nbsp;笔</div>
      <div class="data">交易金额<span class="fColor">{{data.irsData.vol/10000}}</span>亿元</div>
      <div class="data" v-if="data.irsData.sameCompare && data.irsData.sameCompare.indexOf('-')==-1">同比增长<span class="fColor">{{data.irsData.sameCompare}}</span></div>
      <div class="data" v-if="data.irsData.linkRelative && data.irsData.linkRelative.indexOf('-')==-1">环比增长<span class="fColor">{{data.irsData.linkRelative}}</span></div>
    </div>
    <div class="sirsCon" v-if="data.sirsData">
      <div class="conTitle">标准利率互换</div>
      <div class="data">共成交<span class="fColor">{{data.sirsData.dealNo?data.sirsData.dealNo:0}}</span>&nbsp;&nbsp;笔</div>
      <div class="data">交易金额<span class="fColor">{{data.sirsData.vol?data.sirsData.vol/10000:0}}</span>亿元</div>
    </div>
    <div class="sbfCon" v-if="data.sbfData">
      <div class="conTitle">标准债券远期</div>
      <div class="data">共成交<span class="fColor">{{data.sbfData.dealNo?data.sbfData.dealNo:0}}</span>&nbsp;&nbsp;笔</div>
      <div class="data">交易金额<span class="fColor">{{data.sbfData.vol?data.sbfData.vol/10000:0}}</span>亿元</div>
      <div class="data" v-if="data.sbfData.sameCompare && data.sbfData.sameCompare.indexOf('-')==-1">同比增长<span class="fColor">{{data.sbfData.sameCompare?data.sbfData.sameCompare:0}}</span></div>
      <div class="data" v-if="data.sbfData.linkRelative && data.sbfData.linkRelative.indexOf('-')==-1">环比增长<span class="fColor">{{data.sbfData.linkRelative?data.sbfData.linkRelative:0}}</span></div>
    </div>
  </div>
</template>

<script lang="ts">
import { createNamespacedHelpers } from 'vuex'

const { mapState, mapActions } = createNamespacedHelpers('compareData')
export default {
  name: 'compareData',
  data: function () {
    return {
      interval: 0
    }
  },
  created: function () {
    this.interval = setInterval(() => {
      this.getCompareData()
    }, 1000)
  },
  methods: {
    // 在 `hotTrading 数据模块` 中查找并绑定方法
    ...mapActions(['getCompareData'])
  },
  computed: {
    ...mapState({
      data: state => state.data
    })
  },
  beforeDestroy: function () {
    if (this.interval) {
      clearInterval(this.interval)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
.compare {
  position: relative;
  height: 45%;
  color:#9fd2e3;
  text-align: left;
  margin-top: 14.5%;
}
.con {
	background: url('../assets/compare.png') no-repeat center;
  background-size: 100% 100%;
  width: 13.125rem;
  height: 13.125rem;
  padding-left: 2.25rem;
  padding-top: 2.125rem;
  padding-right: 0.9375rem;
  position: absolute;
}
.crpoCon {
  .con;
  top: 0px;
  left: 0px;
}
.cbtCon {
  .con;  
  top: 0px;
  left: calc(50% - 6.5625rem);
}
.irsCon {
  .con;
  top: 0px;
  right: 0px;
}
.sirsCon {
  .con;
  bottom: 0px;
  left: 16%;
}
.sbfCon {
  .con;
  bottom: 0px;
  right: 16%;
}
.conTitle {
  font-size: 1rem;
  line-height: 2rem;
  margin-bottom: 0.2rem;
}
.data {
  font-size: 0.8rem;
  line-height: 1.4rem;
}
.fColor {
  color: #fff;
  font-size: 1.2rem;
  margin-left: 0.2rem;
}
</style>
