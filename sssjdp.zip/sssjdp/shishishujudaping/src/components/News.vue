<template>
  <div class="login-info">
    <!-- 新闻列表 -->
    <div class="newCon rCon">
      <div class="rNewItem" v-if="data.sirsNew">{{data.sirsNew}}</div>
      <div class="rlaunch"></div>
      <div class="container ">
        <div class="red dot"></div>
        <div class="redPulse pulse"></div>
      </div>
    </div>
    <div class="newCon yCon">
      <div class="rNewItem" v-if="data.cbtNew">{{data.cbtNew}}</div>
      <div class="ylaunch"></div>
      <div class="container ">
        <div class="yellow dot"></div>
        <div class="yellowPulse pulse"></div>
      </div>
    </div>
    <div class="newCon bCon">
      <div class="rNewItem blueItem" v-if="data.sbfNew">{{data.sbfNew}}</div>
      <div class="blaunch"></div>
      <div class="container ">
        <div class="blue dot"></div>
        <div class="bluePulse pulse"></div>
      </div>
    </div>
    <div class="newCon gCon">
      <div class="rNewItem" v-if="data.crpoNew">{{data.crpoNew}}</div>
      <div class="glaunch"></div>
      <div class="container ">
        <div class="green dot"></div>
        <div class="greenPulse pulse"></div>
      </div>
    </div>
    <div class="newCon pCon">
      <div class="rNewItem" v-if="data.irsNew">{{data.irsNew}}</div>
      <div class="plaunch"></div>
      <div class="container ">
        <div class="purple dot"></div>
        <div class="purplePulse pulse"></div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { createNamespacedHelpers } from 'vuex'

const { mapState, mapActions } = createNamespacedHelpers('news')
export default {
  name: 'news',
  data: function () {
    return {
      interval: 0
    }
  },
  created: function () {
    this.interval = setInterval(() => {
      this.getNewsData()
    }, 1000)
  },
  methods: {
    // 在 `hotTrading 数据模块` 中查找并绑定方法
    ...mapActions(['getNewsData'])
  },
  computed: {
    ...mapState({
      count: state => state.count,
      hotTradingList: state => state.hotTradingList,
      data: state => state.data
    })
  },
  beforeDestroy: function () {
    if (this.interval) {
      clearInterval(this.interval)
    }
  }
}
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
    .login-info {
      position: relative;
      height: 40%;
    }
    @keyframes warn {
      0% {transform: scale(0);opacity: 0.0;}
      10% {transform: scale(0.2);opacity: 0.2;}
      20% {transform: scale(0.4);opacity: 0.4;}
      30% {transform: scale(0.6);opacity: 0.6;}
      40% {transform: scale(0.8);opacity: 0.8;}
      50% {transform: scale(1);opacity: 1;}
      60% {transform: scale(1);opacity: 0.8;}
      70% {transform: scale(1);opacity: 0.6;}
      80% {transform: scale(1);opacity: 0.4;}
      90% {transform: scale(1);opacity: 0.2;}
      100% {transform: scale(1);opacity: 0;}
    }
    @keyframes launchWarn {
      0%{height:0px;left:2.5rem;top:-10rem;position: relative;}
      100%{height:12.5rem;top:-0.625rem;position: relative;}
    }
    .newCon {
      width: 3.75rem;
      height: 12.5rem;
      position: absolute;
    }
    .container {
      width: 4.375rem;
      height: 4.375rem;
      animation: warn .7s ease-out;
      animation-iteration-count: infinite;
    }
    .launch {
      background-size: 100%;
      width: 1.5rem;
      height: 8.75rem;
      margin-left: 1.6875rem;
      position: relative;
      top: 3.4375rem;
      z-index: 10000;
      /* animation: launchWarn 30s ease-out; 
      animation-iteration-count: 1; */
    }
    .rlaunch {
      .launch;
      background: url('../assets/signal4.png') no-repeat center center;
    }
    .ylaunch {
      .launch;
      background: url('../assets/signal2.png') no-repeat center center;
    }
    .blaunch {
      .launch;
      background: url('../assets/signal5.png') no-repeat center center;
    }
    .glaunch {
      .launch;
      background: url('../assets/signal1.png') no-repeat center center;
    }
    .plaunch {
      .launch;
      background: url('../assets/signal3.png') no-repeat center center;
    }
    .rNewItem {
      background: url('../assets/newsBg.png') no-repeat center center;
      background-size: 100%;
      width: 12.5rem;
      height: 4.75rem;
      left: 3.125rem;
      position: relative;
      top: 3.75rem;
      float: left;
      color: #fff;
      text-align: left;
      padding-top: 1.15rem;
      padding-left: 0.9375rem;
      padding-right: 0.625rem;
      font-size: 0.85rem;
      line-height: 1rem;
    }
    .pItem {
      left: -10.7rem;
    }
    .blueItem {
      left: -10.625rem;
      top:4.375rem
    }
    .rCon {
      right: 12.5rem;
      bottom: 0px;
    }
    .yCon {
      right: 8.75rem;
      top: 5rem;
    }
    .bCon {
      left: 7.5rem;
      top: 5.7rem;
    }
    .gCon {
      left: 17rem;
      top: -0.625rem;
    }
    .pCon {
      left: 9.5rem;
      bottom: 1.25rem;
    }
    /*保持大小不变的小圆圈*/
    .dot {
      position: absolute;
      left: 1.5rem;
      top: 1.5rem;
      width: 1.875rem;
      height: 1.875rem;
      border-radius: 0.9375rem;
      -webkit-border-radius: 0.9375rem;
      -moz-border-radius: 0.9375rem;
      border: 1px solid #27f8fc;
      background: #3677a7;
      z-index: 2;
      animation: warn .5s ease-out;
      animation-iteration-count: infinite;
    }
    /*产生动画（向外扩散变大）的圆圈*/
    .pulse {
      position: absolute;
      width: 3.125rem;
      height: 3.125rem;     
      -webkit-border-radius: 2.1875rem;
      -moz-border-radius: 2.1875rem;
      border-radius: 2.1875rem;
      left: 0.875rem;
      top: 0.875rem;
      z-index: 1;
    }
    .red {
      border: 1px solid #bd4866;
      background: #f86471;
    }
    .redPulse {      
      border: 1px solid #612053;
      background: #612053;
    }
    .yellow {
      border: 1px solid #e6c16b;
      background: #f5cf64;
    }
    .yellowPulse {      
      border: 1px solid #5c456e;
      background: #5c456e;
    }
    .blue {
      border: 1px solid #597ec8;
      background: #68a5fd;
    }
    .bluePulse {      
      border: 1px solid #3b497d;
      background: #4f5197;
    }
    .green {      
      border: 1px solid #0cedf8;
      background: #3577a4;
    }
    .greenPulse {      
      border: 1px solid #3b497d;
      background: #434c7e;
    }
    .purple {
      border: 1px solid #7635c0;
      background: #894cd2;
    }
    .purplePulse {      
      border: 1px solid #3b497d;
      background: #434c7e;
    }
</style>