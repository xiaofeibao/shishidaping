<template>
  <!-- 20家机构登录用户数柱状图 -->
  <div>
        <div
          id="loginListChartId"
        >
      </div>
  </div>
</template>

<script lang="ts">
import { createNamespacedHelpers } from 'vuex'

const { mapState, mapActions } = createNamespacedHelpers('loginListChart')

export default {
  name: 'LoginListChart',
  data: function () {
    return {
      interval: 0,
      chart: null
    }
  },
  created: function () {
    this.getLoginListChart()
    this.interval = setInterval(() => {
      this.getLoginListChart()
    }, 1000)
  },
  methods: {
    // 在 `hotTrading 数据模块` 中查找并绑定方法
    ...mapActions(['getLoginListChart']),
    initChart () {
      let yMax = 300
      let zoomSize = 1
      let options: object = { // 柱状图
        grid: { 
          containLabel: true,
          left: '15%'
        },
        xAxis: { 
          name: '',
          axisLabel: {
            inside: false, //true ：横坐标字在柱子上
            textStyle: {
              color: '#9fd2e3', //横坐标文字颜色
              fontSize: '100%'
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            show: false
          },
          splitLine: {
            show: false
          },
          z: 10,
          minInterval: 1
        },
        yAxis: { 
          type: 'category',
          splitNumber: 20,
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            textStyle: {
              color: '#9fd2e3',
              fontSize: '100%'
            }
          },

        },
        visualMap: {
          orient: 'horizontal',
          left: 'center',
          min: 100,
          max: 500,
          // // text: ['High Score', 'Low Score'],
          // // Map the score column to color
          dimension: 0,
          inRange: {
            color: ['#0a265c','#074686','#065296','#0495cb','#27f8fc']
          },
          show: false
        },
        series: [
          {
            type: 'bar',
            
          }
        ],
      }
      const ele = document.getElementById('loginListChartId')
      this.chart = this.$echarts.init(ele)
      if (options && typeof options === 'object') {
        this.chart.setOption(options, true)
      }
    }
  },
  computed: {
    ...mapState({
      loginList: (state: any) => state.loginList
    })
  },
  watch: {
    loginList(loginList){
      this.chart.setOption({
        series: [
          {
            type: 'bar',
            data: loginList
          }
        ]
      });
    }
  },
  mounted: function() {
    this.$nextTick(() => {
      this.initChart()
    })
  },
  beforeDestroy: function () {
    if (this.interval) {
      clearInterval(this.interval)
    }
  }
  // @Prop({ default: 'chart' }) private className!: string
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  #loginListChartId {
    width: 100%;
    height: 100%;
  }
</style>