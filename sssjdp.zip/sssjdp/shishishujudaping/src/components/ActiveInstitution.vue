<template>
  <div class="login-info">
    成交数据对比
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator'

@Component
export default class ActiveInstitution extends Vue {
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
    .login-info {
        border: 1px solid red;
    }
</style>
